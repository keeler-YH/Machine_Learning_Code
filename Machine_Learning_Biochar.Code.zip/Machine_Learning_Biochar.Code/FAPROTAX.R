path2 <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/3_SRA.to.phyloseq/list.Forest/"  
 
file_names <- list.files(path = path2, pattern = "bac.process$", full.names = FALSE)
i <- 0
for(file in file_names){
  i <- i+1
  #file <- "PRJNA990956-48-49-bac.process"
  result_path <- file.path(path2, file, "result", "otutab.txt")  
  otutab <- read.delim(result_path, header = TRUE, sep = "\t")  
  
  result_path1 <- file.path(path2, file, "result", "taxonomy2.txt")  
  taxonomy <- read.delim(result_path1, header = FALSE, sep = "\t", col.names = c("ASV", "taxonomy")) 
  
  merged_data <- merge(otutab, taxonomy, by.x = "X.OTU.ID", by.y = "ASV", all.x = TRUE)
  write.table(merged_data, paste0("D:/FAPROTAX/data.Forest/otutab_with_taxonomy.",i,".txt"), sep = "\t", row.names = FALSE, quote = FALSE)
  
}

#python /mnt/d/FAPROTAX/FAPROTAX_1.2.10/FAPROTAX_1.2.10/collapse_table.py -i /mnt/d/FAPROTAX/data/otutab_with_taxonomy.txt -o qii1_otu_tax_faprtax.txt -g /mnt/d/FAPROTAX/FAPROTAX_1.2.10/FAPROTAX_1.2.10/FAPROTAX.txt -r report.txt -v -d 'taxonomy'

input_file.bac <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/1_1_ID_to_listFile/download/bac_metadata_Forest.soil.csv"
bac_metadata <- read.csv(input_file.bac, header = T)
folder_path <- "D:/FAPROTAX/data.Forest/"

file_list <- list.files(path = folder_path, pattern = "faprtax.txt$", full.names = TRUE)
resu <- list()
i <- 0
for (file in file_list) {
  i <- i+1
  print(i)
 
  data <- read.table(file, header = TRUE, sep = "\t",stringsAsFactors = FALSE)
  srr_samples <- colnames(data)[-1:-2]  
  matching_rows <- match(srr_samples, bac_metadata$Sample.names)
  matched_info <- bac_metadata$Group[matching_rows]
  colnames(data)[-1:-2] <- matched_info
  
  biochar_columns <- grep("^Biochar", colnames(data))
  control_columns <- grep("^Control", colnames(data))
  
  if (length(biochar_columns) > 1) {
    data$Biochar_sum <- rowSums(data[, biochar_columns], na.rm = TRUE)
  } else if (length(biochar_columns) == 1) {
    data$Biochar_sum <- data[, biochar_columns]
  } else {
    data$Biochar_sum <- 0
  }
  # 计算 Control_sum
  if (length(control_columns) > 1) {
    data$Control_sum <- rowSums(data[, control_columns], na.rm = TRUE)
  } else if (length(control_columns) == 1) {
    data$Control_sum <- data[, control_columns]
  } else {
    data$Control_sum <- 0
  }
  

  # ...
  new_data <- data.frame(group = data$group, Biochar_sum = data$Biochar_sum, Control_sum = data$Control_sum)
  resu[[i]] <-  new_data
}

final_dataframe <- do.call(rbind, resu)

head(final_dataframe)

library(dplyr)


final_dataframe_merged <- final_dataframe %>%
  group_by(group) %>%
  summarise(
    Biochar_sum = sum(Biochar_sum, na.rm = TRUE),
    Control_sum = sum(Control_sum, na.rm = TRUE)
  )

head(final_dataframe_merged)

final_dataframe_merged_df <- as.data.frame(final_dataframe_merged)

head(final_dataframe_merged_df)
data1 <- final_dataframe_merged_df

#file_path <- "D:/FAPROTAX/FAPROTAX_1.2.10/FAPROTAX_1.2.10/qii1_otu_tax_faprtax.txt"

#data <- read.table(file = file_path, header = TRUE, sep = "\t", stringsAsFactors = FALSE)

#head(data)
#data1 <- data[,-2]

total_biochar <- sum(data1$Biochar_sum, na.rm = TRUE)
total_control <- sum(data1$Control_sum, na.rm = TRUE)
# Calculating relative abundance
data1$Biochar <- data1$Biochar_sum / total_biochar
data1$Control <- data1$Control_sum / total_control
# View Results
head(data1)

data1_sorted <- data1[order(data1$Biochar_sum, decreasing = TRUE), ]  
data1_sorted1 <- data1_sorted[1:30,c(1,4,5)]
write.table(data1_sorted1, "D:/FAPROTAX/data1_sorted1.Forest.RA.csv", sep = ",", row.names = FALSE, quote = FALSE)
 # Convert data from wide format to long format
data_melt <- melt(data1_sorted1, id.vars = "group", variable.name = "Sample", value.name = "Abundance")


data_melt$Sample <- factor(data_melt$Sample, levels = unique(data_melt$Sample))  
data_melt$group <- factor(data_melt$group, levels = unique(data_melt$group))    
# Plotting bubbles with ggplot2 
library(ggplot2)  
ggplot(data_melt, aes(x = Sample, y = group, size = Abundance, fill = Abundance)) +  
  geom_point(shape = 21, colour = "black") +  
  scale_size(range = c(3, 10)) +  
  scale_fill_gradient(low = "blue", high = "red") +  
  theme_minimal() +  
  labs(x = "Type", y = "Function", size = "Ralative Abundance", fill = "Ralative Abundance") +  
  theme(axis.text.x = element_text(color = "black",face = "bold",angle = 45, hjust = 1),
        axis.text.y = element_text(color = "black",face = "bold"),
        axis.title.x = element_text(color = "black",face = "bold"),
        axis.title.y = element_text(color = "black",face = "bold"),
        legend.text = element_text(color = "black",face = "bold"),
        legend.title = element_text(color = "black", face = "bold"))




data.Forest.RA <- read.table("D:/FAPROTAX/data1_sorted1.Forest.RA.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)
data.Forest.RA$scaled_Biochar <- log10(data.Forest.RA$Biochar) # Using squares to magnify gaps
data.Forest.RA$scaled_Control <- log10(data.Forest.RA$Control)  # Or use log10(data.Forest.RA$Biochar) for logarithmic transformation
data.Forest.RA1 <- data.Forest.RA[, c("group", "scaled_Biochar", "scaled_Control")]
colnames(data.Forest.RA1) <- c("group", "Biochar", "Control") 
data_melt <- melt(data.Forest.RA1, id.vars = "group", variable.name = "Sample", value.name = "Abundance")
data_melt$Sample <- factor(data_melt$Sample, levels = unique(data_melt$Sample))  
data_melt$group <- factor(data_melt$group, levels = unique(data_melt$group))    
# Plotting bubbles with ggplot2   
library(ggplot2)  
ggplot(data_melt, aes(x = Sample, y = group, size = Abundance, fill = Abundance)) +  
  geom_point(shape = 21, colour = "black") +  
  scale_size(range = c(3, 10)) +  
  scale_fill_gradient(low = "blue", high = "red") +  
  theme_minimal() +  
  labs(x = "Type", y = "Function", size = "log10(RA)", fill = "log10(RA)") +  
  theme(axis.text.x = element_text(color = "black",face = "bold",angle = 45, hjust = 1),
        axis.text.y = element_text(color = "black",face = "bold"),
        axis.title.x = element_text(color = "black",face = "bold"),
        axis.title.y = element_text(color = "black",face = "bold"),
        legend.text = element_text(color = "black",face = "bold"),
        legend.title = element_text(color = "black", face = "bold"))


data.Farmland.RA <- read.table("D:/FAPROTAX/data1_sorted1.Farmland.RA.csv", header = TRUE, sep = ",", stringsAsFactors = FALSE)
data.Farmland.RA$scaled_Biochar <- log10(data.Farmland.RA$Biochar) # Using squares to magnify gaps
data.Farmland.RA$scaled_Control <- log10(data.Farmland.RA$Control)  # Or use log10(data.Forest.RA$Biochar) for logarithmic transformation
data.Farmland.RA1 <- data.Farmland.RA[, c("group", "scaled_Biochar", "scaled_Control")]
colnames(data.Farmland.RA1) <- c("group", "Biochar", "Control") 
data_melt <- melt(data.Farmland.RA1, id.vars = "group", variable.name = "Sample", value.name = "Abundance")
data_melt$Sample <- factor(data_melt$Sample, levels = unique(data_melt$Sample))  
data_melt$group <- factor(data_melt$group, levels = unique(data_melt$group))    
# Plotting bubbles with ggplot2   
library(ggplot2)  
ggplot(data_melt, aes(x = Sample, y = group, size = Abundance, fill = Abundance)) +  
  geom_point(shape = 21, colour = "black") +  
  scale_size(range = c(3, 10)) +  
  scale_fill_gradient(low = "blue", high = "red") +  
  theme_minimal() +  
  labs(x = "Type", y = "Function", size = "log10(RA)", fill = "log10(RA)") +  
  theme(axis.text.x = element_text(color = "black",face = "bold",angle = 45, hjust = 1),
        axis.text.y = element_text(color = "black",face = "bold"),
        axis.title.x = element_text(color = "black",face = "bold"),
        axis.title.y = element_text(color = "black",face = "bold"),
        legend.text = element_text(color = "black",face = "bold"),
        legend.title = element_text(color = "black", face = "bold"))


