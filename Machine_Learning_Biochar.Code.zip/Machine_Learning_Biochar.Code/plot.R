library(ggClusterNet)
library(phyloseq)
library(tidyverse)


library(randomForest)
library(caret)
library(ROCR) ##用于计算ROC
library(e1071)

# 加载必要的包
library(ggplot2)
library(ggsci)      # 提供 Nature (npg) 配色
library(showtext)   # 增强字体渲染稳定性

MLpath <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/biochar/bac/new/pics"
ps0 = base::readRDS("./ps.orig.unoise3.bac.Forest.Genus.rds")
ps0
map = ps0 %>% sample_data()
dim(map)
input_file.bac <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/1_1_ID_to_listFile/download/bac_metadata_Forest.filtered.soil.csv"
# 导入CSV文件
bac_metadata <- read.csv(input_file.bac, header = T)
bac_metadata$Group <- trimws(bac_metadata$Group)
match_indices <- match(map$ID, bac_metadata$Sample.names)
map$Group <- bac_metadata[match_indices,11]
map$assid %>% unique()
#map$Group = c(rep("Biochar",672),rep("Control",500))
#map$Group = as.factor(map$Group)
sample_data(ps0) = map
#  去除空缺值--空缺值来源合并样本
otu = ps0 %>% vegan_otu() %>% t() 
otu[is.na(otu)] = 0
#标准化
otu <- data.frame(apply(otu,2,function(x) x/sum(x))*100,stringsAsFactors = FALSE)
otu_table(ps0) = otu_table(as.matrix(otu),taxa_are_rows = TRUE)
#-分组都是两两比较
i = 1
map= sample_data(ps0)
head(map)
id.g = map$Group %>% unique() %>% as.character() %>% combn(2)
ps.cs = ps0 %>% subset_samples.wt("Group" ,id.g[,i])

#1.随机森林#------
map = as.data.frame(phyloseq::sample_data(ps.cs))
otutab = as.data.frame(t(ggClusterNet::vegan_otu(ps.cs)))
colnames(otutab) <- gsub("-","_",colnames(otutab)) 
test = as.data.frame(t(otutab))
test$group = factor(map$Group)
test <- test[, colnames(test) != "Unassigned"]
#colnames(test) = paste("OTU",colnames(test),sep = "")

colnames(test) <- gsub("-","_",colnames(test))
colnames(test) <- gsub("[/]","_",colnames(test))
colnames(test) <- gsub("[(]","_",colnames(test))
colnames(test) <- gsub("[)]","_",colnames(test))
colnames(test) <- gsub("[:]","_",colnames(test))
colnames(test) <- gsub("[[]","",colnames(test))
colnames(test) <- gsub("[]]","_",colnames(test))
colnames(test) <- gsub("[#]","_",colnames(test))
colnames(test) <- gsub("[+]","_",colnames(test))
colnames(test) <- gsub(" ","_",colnames(test))

test = dplyr::select(test,group,everything())
train = test


set.seed(123)
folds <- createFolds(y=test[,1],k=10)
index.train <- sample(length(test[,1]),length(test[,1])*0.75)
fold_train<-train[index.train,]
fold_test<-train[-index.train,]



# 1. 准备 10 折交叉验证的索引 (使用训练集进行 CV)
set.seed(123)
# 假设您的目标变量列名为 group
cv_folds <- createFolds(fold_train$group, k = 10)

# 2. 超参数网格
tune_grid <- expand.grid(
  mtry = c(20,50,100,500,1000,1200,1500,2000,5000),
  ntree = c(100,500, 1000, 1200, 1500, 2000),
  nodesize = c(3,5,7,10)
)

# 3. 创建空数据框存储最终平均结果
results_cv <- data.frame()

start_time <- Sys.time()
# --- 开始超参数遍历循环 ---
for (i in 1:nrow(tune_grid)) {
  cat(sprintf("\n[进度] 正在处理第 %d / %d 组超参数...", i, nrow(tune_grid)))
  
  mtry_val <- tune_grid$mtry[i]
  ntree_val <- tune_grid$ntree[i]
  nodesize_val <- tune_grid$nodesize[i]
  
  # 创建临时向量存储这 10 折的指标
  fold_accuracies <- c()
  fold_kappas <- c()
  
  # --- 内部嵌套循环：10 折交叉验证 ---
  for (j in 1:10) {
    # 提取第 j 折的训练索引
    train_idx <- cv_folds[[j]]
    
    # 划分 CV 训练集和 CV 验证集
    cv_train_data <- fold_train[-train_idx, ] # 9 份
    cv_val_data   <- fold_train[train_idx, ]  # 1 份
    
    # 训练模型
    set.seed(123) # 保证单次森林构建可重复
    rf_temp <- randomForest(
      group ~ ., 
      data = cv_train_data,
      mtry = mtry_val,
      ntree = ntree_val,
      nodesize = nodesize_val
    )
    
    # 验证并计算指标
    pred_temp <- predict(rf_temp, newdata = cv_val_data)
    cm_temp <- confusionMatrix(pred_temp, cv_val_data$group)
    
    fold_accuracies[j] <- cm_temp$overall["Accuracy"]
    fold_kappas[j]     <- cm_temp$overall["Kappa"]
  }
  
  # 计算 10 次验证的平均值
  avg_acc <- mean(fold_accuracies)
  avg_kap <- mean(fold_kappas)
  
  # 将结果存入汇总表
  results_cv <- rbind(results_cv, data.frame(
    mtry = mtry_val, 
    ntree = ntree_val, 
    nodesize = nodesize_val, 
    Accuracy = avg_acc, 
    Kappa = avg_kap
  ))
}

# 保存最终交叉验证后的结果
write.csv(results_cv, "Forest.rf_results_10fold_CV.csv", row.names = FALSE)
print(head(results_cv))

end_time <- Sys.time()

# 计算差值
run_time <- end_time - start_time
print(run_time)


# 设置文件路径
file_path <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/Forest.rf_results_10fold_CV.csv"
# 读取CSV文件，header=T表示文件包含列名
results <- read.csv(file_path, header = TRUE)
# 查看数据框的前几行，确保导入成功
head(results)


##补充图Accuracy#------


results$mtry <- as.factor(results$mtry)
results$ntree <- as.factor(results$ntree)
results$nodesize <- as.factor(results$nodesize)




# 1. 字体配置 (解决之前的 Arial 找不到的问题)
# Nature 常用 Arial。Arimo 是其开源替代方案，排版比例 1:1
font_add_google("Arimo", "arial")
showtext_auto()

# 2. 预处理数据
results$ntree <- factor(results$ntree)
results$nodesize_lab <- paste0("nodesize: ", results$nodesize)


# 3. 绘图：大幅调大字号，达到 Nature 出版级清晰度
pA <- ggplot(results, 
             aes(x = mtry, y = Accuracy, 
                 group = ntree, color = ntree)) +
  # 增加点和线的粗细，以匹配大字号
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # 分面：使用带 nodesize 描述的标签
  facet_wrap(~nodesize_lab, ncol = 2) + 
  
  # 配色方案：采用 Nature (NPG) 官方配色
  scale_color_npg() + 
  
  # 标签：已去掉主标题
  labs(x = "mtry", 
       y = "Accuracy", 
       color = "ntree") +
  
  # 基础主题
  theme_bw() + 
  theme(
    # —— 核心：大幅调大并加粗字体 ——
    text = element_text(family = "arial", face = "bold", color = "black"),
    
    # 坐标轴标题（Nature 推荐 9-10pt，此处设为大字号 14pt 以便您在电脑上查看）
    axis.title.x = element_text(size = 28, margin = ggplot2::margin(t = 12)),
    axis.title.y = element_text(size = 28, margin = ggplot2::margin(r = 12)),
    
    # 刻度文字（Nature 推荐 7pt，此处设为 12pt）
    axis.text = element_text(size = 20, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # 分面标签背景与文字（Nature 推荐 8-9pt，此处设为 12pt）
    strip.background = element_rect(color = NA, fill = "white"),
    strip.text = element_text(size =20, face = "bold"),
    
    # 这行代码控制小图四周完整的矩形边框
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.0),
    
    # —— 洁净外观：去掉网格线 ——
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # 刻度线加粗
    axis.ticks = element_line(linewidth = 0.8, color = "black"),
    
    # 图例设置
    legend.title = element_text(size = 28, face = "bold"),
    legend.text = element_text(size = 20),
    legend.position = "right",
    legend.key = element_blank()
  )

# 显示图像
print(pA)



##补充图Kappa##------ 
pD <- ggplot(results, 
             aes(x = mtry, y = Kappa, 
                 group = ntree, color = ntree)) +
  # 增加点和线的粗细，以匹配大字号
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # 分面：使用带 nodesize 描述的标签
  facet_wrap(~nodesize_lab, ncol = 2) + 
  
  # 配色方案：采用 Nature (NPG) 官方配色
  scale_color_npg() + 
  
  # 标签：已去掉主标题
  labs(x = "mtry", 
       y = "Kappa", 
       color = "ntree") +
  
  # 基础主题
  theme_bw() + 
  theme(
    # —— 核心：大幅调大并加粗字体 ——
    text = element_text(family = "arial", face = "bold", color = "black"),
    
    # 坐标轴标题（Nature 推荐 9-10pt，此处设为大字号 14pt 以便您在电脑上查看）
    axis.title.x = element_text(size = 28, margin = ggplot2::margin(t = 12)),
    axis.title.y = element_text(size = 28, margin = ggplot2::margin(r = 12)),
    
    # 刻度文字（Nature 推荐 7pt，此处设为 12pt）
    axis.text = element_text(size = 20, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # 分面标签背景与文字（Nature 推荐 8-9pt，此处设为 12pt）
    strip.background = element_rect(color = NA, fill = "white"),
    strip.text = element_text(size = 20, face = "bold"),
    
    # 这行代码控制小图四周完整的矩形边框
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.0),
    
    # —— 洁净外观：去掉网格线 ——
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # 刻度线加粗
    axis.ticks = element_line(linewidth = 0.8, color = "black"),
    
    # 图例设置
    legend.title = element_text(size = 28, face = "bold"),
    legend.text = element_text(size = 20),
    legend.position = "right",
    legend.key = element_blank()
  )

# 显示图像
print(pD)

#2.SVM(Support Vector Machine)##----
# svm_grid <- expand.grid(
#   sigma = c(0.001, 0.01,0.05,0.1,0.5,1,5,10),
#   C = c(0,0.01, 0.05, 0.1,0.2 ,0.3, 0.4, 0.5, 1, 1.25, 1.5, 1.75, 2,5))
# 
# set.seed(321)
# svm_fit <- train(group ~., 
#                  data = data_train, method = "svmRadial",
#                  trControl = tr,
#                  preProcess = c("center", "scale"),
#                  tuneGrid = svm_grid,
#                  tuneLength = 10,
#                  metric = "Accuracy")
# 
# print(svm_fit)

library(e1071)
library(caret)
# 1. 定义超参数组合 (sigma × C)
svm_grid <- expand.grid(
  sigma = c(0.001, 0.01, 0.05, 0.1, 0.2, 0.5, 1,3),  # 你可以根据需要设置 sigma 的范围
  C = c(0.001, 0.01, 0.05, 0.1, 0.5, 1, 2,3)       # C需大于0
)


# 2. 创建空数据框存储结果
svm_results <- data.frame(sigma = numeric(), cost = numeric(), 
                          Accuracy = numeric(), Kappa = numeric())

# 3. 创建十折交叉验证控制对象
train_control <- trainControl(method = "cv", number = 10)  # 10 折交叉验证

start_time <- Sys.time()

# 4. 使用 for 循环遍历每个超参数组合
for (i in 1:nrow(svm_grid)) {
  # 打印当前进度
  print(paste("Processing iteration:", i))
  
  sigma_val <- svm_grid$sigma[i]
  cost_val  <- svm_grid$C[i]
  
  # 5. 训练 SVM 模型并进行十折交叉验证
  set.seed(321)
  
  # 使用 caret 包中的 train() 函数进行交叉验证
  svm_model <- train(
    group ~ ., 
    data = fold_train, 
    method = "svmRadial", 
    trControl = train_control, 
    tuneGrid = data.frame(sigma = sigma_val, C = cost_val)
  )
  
  # 6. 提取交叉验证的结果
  accuracy <- svm_model$results$Accuracy
  kappa <- svm_model$results$Kappa
  
  # 7. 将当前结果添加到 svm_results
  svm_results <- rbind(svm_results, data.frame(
    sigma = sigma_val, 
    cost = cost_val, 
    Accuracy = accuracy, 
    Kappa = kappa
  ))
}

end_time <- Sys.time()
print(end_time - start_time)

# 输出结果
print(svm_results)
write.csv(svm_results, "Farmland.svm_results_cv.csv", row.names = FALSE)
file_path <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/Forest.svm_results_cv.csv"

svm_results <- read.csv(file_path, header = TRUE, stringsAsFactors = FALSE)

head(svm_results)




library(ggplot2)
library(ggsci)

## 补充图Accuracy#----
# 1. 数据预处理
# 确保 sigma 和 cost 都是因子，以便在图中清晰展示
svm_results$sigma_f <- factor(svm_results$sigma)
svm_results$cost_f <- factor(svm_results$cost)

# 2. 绘图：模仿 RF 的 B 图风格
p_svm_single <- ggplot(svm_results, 
                       aes(x = sigma_f, y = Accuracy, 
                           group = cost_f, color = cost_f)) +
  
  # —— 核心：线和点的参数 (0.7 和 2.2) ——
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # —— 配色：采用支持更多颜色的顶刊配色 (IGV) ——
  scale_color_igv(name = "cost") + 
  
  # 标签设置
  labs(x = "sigma", 
       y = "Accuracy") +
  
  # —— 基础主题与出版级细节调整 ——
  theme_bw() + 
  theme(
    # ❶ 字体大幅加大并加粗 (16pt 以上)
    text = element_text(family = "arial", face = "bold", color = "black"),
    
    # 坐标轴标题
    axis.title.x = element_text(size = 28, margin = ggplot2::margin(t = 15)),
    axis.title.y = element_text(size = 28, margin = ggplot2::margin(r = 15)),
    
    # 刻度文字
    axis.text = element_text(size = 20, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # ❷ 彻底去掉背景网格线
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # ❸ 边框与刻度线加粗
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.5),
    axis.ticks = element_line(linewidth = 1.0, color = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    
    # ❹ 图例设置 (因为有14条线，图例需调大)
    legend.position = "right",
    legend.title = element_text(size = 28, face = "bold"),
    legend.text = element_text(size = 20),
    legend.key = element_blank(),
    legend.background = element_blank()
  )

# 显示图像
print(p_svm_single)


##补充图Kappa##----
# 2. 绘图：模仿 RF 的 B 图风格
p_svm_single <- ggplot(svm_results, 
                       aes(x = sigma_f, y = Kappa, 
                           group = cost_f, color = cost_f)) +
  
  # —— 核心：线和点的参数 (0.7 和 2.2) ——
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # —— 配色：采用支持更多颜色的顶刊配色 (IGV) ——
  scale_color_igv(name = "cost") + 
  
  # 标签设置
  labs(x = "sigma", 
       y = "Kappa") +
  
  # —— 基础主题与出版级细节调整 ——
  theme_bw() + 
  theme(
    # ❶ 字体大幅加大并加粗 (16pt 以上)
    text = element_text(family = "arial", face = "bold", color = "black"),
    
    # 坐标轴标题
    axis.title.x = element_text(size = 28, margin = ggplot2::margin(t = 12)),
    axis.title.y = element_text(size = 28, margin = ggplot2::margin(r = 12)),
    
    # 刻度文字
    axis.text = element_text(size = 20, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # ❷ 彻底去掉背景网格线
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # ❸ 边框与刻度线加粗
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.5),
    axis.ticks = element_line(linewidth = 1.0, color = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    
    # ❹ 图例设置 (因为有14条线，图例需调大)
    legend.position = "right",
    legend.title = element_text(size = 28, face = "bold"),
    legend.text = element_text(size = 20),
    legend.key = element_blank(),
    legend.background = element_blank()
  )

# 显示图像
print(p_svm_single)


#3.XGBoost##----
library(caret)

# 1. 定义参数网格
tune_grid_xgb <- expand.grid(
  nrounds = c(100, 200, 300, 400, 500, 800, 1000, 1200, 1500), 
  eta = c(0.0001, 0.001, 0.005, 0.01, 0.05, 0.1, 
          0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9)
)

# 2. 创建空数据框存储结果
results_xgb <- data.frame(
  nrounds = integer(), 
  eta = numeric(), 
  Accuracy = numeric(), 
  Kappa = numeric()
)

start_time <- Sys.time()

# 3. 开始循环调参（不使用交叉验证）
for (i in 1:nrow(tune_grid_xgb)) {
  
  print(paste("Processing iteration:", i))
  
  nrounds_val <- tune_grid_xgb$nrounds[i]
  eta_val     <- tune_grid_xgb$eta[i]
  
  # 4. 训练 XGBoost 模型（无交叉验证）
  set.seed(123)
  
  xgb_model <- train(
    group ~ ., 
    data   = fold_train, 
    method = "xgbTree",
    
    # 只调 nrounds 和 eta，其它参数固定
    tuneGrid = data.frame(
      nrounds = nrounds_val,
      eta = eta_val,
      max_depth = 6,
      gamma = 0,
      colsample_bytree = 0.8,
      min_child_weight = 1,
      subsample = 0.8
    ),
    
    # 关键：不使用交叉验证
    trControl = trainControl(method = "none")
  )
  
  # 5. 在测试集上预测
  pred <- predict(xgb_model, newdata = fold_test)
  pred <- factor(pred, levels = levels(fold_train$group))
  
  # 6. 计算混淆矩阵
  cm <- confusionMatrix(pred, fold_test$group)
  accuracy <- cm$overall["Accuracy"]
  kappa    <- cm$overall["Kappa"]
  
  # 7. 保存结果
  results_xgb <- rbind(results_xgb, data.frame(
    nrounds = nrounds_val, 
    eta     = eta_val, 
    Accuracy = accuracy, 
    Kappa    = kappa
  ))
}

end_time <- Sys.time()
print(end_time - start_time)

# 输出并保存
print(results_xgb)
write.csv(results_xgb, "xgb_tuning_results_no_cv.csv", row.names = FALSE)


### 补充图Acurracy：XGBoost 核心参数优化 ## ---------------------------------
# 转成因子，保证分组和配色正确
results_xgb$eta_f     <- factor(results_xgb$eta)
results_xgb$nrounds_f <- factor(results_xgb$nrounds)
p_xgb_eta <- ggplot(results_xgb, 
                    aes(x = eta_f, 
                        y = Accuracy, 
                        group = nrounds_f, 
                        color = nrounds_f)) +
  
  # —— 核心：线和点参数（与你 RF / SVM 完全一致） ——
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # —— 配色：IGV 顶刊配色 ——
  scale_color_igv(name = "nrounds") + 
  
  # 坐标标签
  labs(x = "eta", 
       y = "Accuracy") +
  
  # —— 出版级主题设置（与你前面统一风格） ——
  theme_bw() + 
  theme(
    # ❶ 字体大幅加大并加粗
    text = element_text(family = "arial", face = "bold", color = "black"),
    
    # 坐标轴标题
    axis.title.x = element_text(size = 18, margin = ggplot2::margin(t = 15)),
    axis.title.y = element_text(size = 18, margin = ggplot2::margin(r = 15)),
    
    # 刻度文字
    axis.text = element_text(size = 14, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # ❷ 去掉网格线
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # ❸ 边框和刻度线加粗
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.5),
    axis.ticks = element_line(linewidth = 1.0, color = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    
    # ❹ 图例设置
    legend.position = "right",
    legend.title = element_text(size = 14, face = "bold"),
    legend.text = element_text(size = 12),
    legend.key = element_blank(),
    legend.background = element_blank()
  )

# 显示图像
print(p_xgb_eta)

### 补充图Kappa：XGBoost 核心参数优化 ## ---------------------------------
# 转成因子，保证分组和图例正确
results_xgb$eta_f      <- factor(results_xgb$eta)
results_xgb$nrounds_f <- factor(results_xgb$nrounds)

p_xgb_kappa <- ggplot(results_xgb, 
                      aes(x = eta_f, 
                          y = Kappa, 
                          group = nrounds_f, 
                          color = nrounds_f)) +
  
  # —— 核心：线和点参数（与你 RF / SVM 完全统一） ——
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # —— 配色：IGV 顶刊配色 ——
  scale_color_igv(name = "nrounds") + 
  
  # 标签设置
  labs(x = "eta", 
       y = "Kappa") +
  
  # —— 出版级主题（完全复刻你前面的风格） ——
  theme_bw() + 
  theme(
    # ❶ 字体加粗加大
    text = element_text(family = "arial", face = "bold", color = "black"),
    
    # 坐标轴标题
    axis.title.x = element_text(size = 18, margin = ggplot2::margin(t = 15)),
    axis.title.y = element_text(size = 18, margin = ggplot2::margin(r = 15)),
    
    # 刻度文字
    axis.text = element_text(size = 14, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # ❷ 去掉背景网格线
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # ❸ 边框与刻度线加粗
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.5),
    axis.ticks = element_line(linewidth = 1.0, color = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    
    # ❹ 图例设置
    legend.position = "right",
    legend.title = element_text(size = 14, face = "bold"),
    legend.text = element_text(size = 12),
    legend.key = element_blank(),
    legend.background = element_blank()
  )

# 显示图像
print(p_xgb_kappa)

#4.GLM##----
library(glmnet)
library(caret)

# 1. 定义 GLM 超参数组合 (alpha × lambda)
glm_grid <- expand.grid(
  alpha  = seq(0, 1, by = 0.1),                 # 11 个 alpha
  lambda = 10^seq(-4, 1, length.out = 30)       # 30 个 lambda（log-scale）
)

start_time <- Sys.time()

# 2. 创建空数据框存储结果
glm_results <- data.frame(alpha = numeric(), 
                          lambda = numeric(), 
                          Accuracy = numeric(), 
                          Kappa = numeric())

# 3. 创建十折交叉验证控制对象
train_control <- trainControl(method = "cv", number = 10)  # 10 折交叉验证

for (i in 1:nrow(glm_grid)) {
  
  # 打印当前进度
  print(paste("Processing iteration:", i))
  
  alpha_val  <- glm_grid$alpha[i]
  lambda_val <- glm_grid$lambda[i]
  
  # 4. 构建设计矩阵（glmnet 需要 matrix 形式）
  x_train <- as.matrix(fold_train[, !(colnames(fold_train) %in% "group")])
  y_train <- fold_train$group
  
  # 5. 训练正则化 GLM（logistic 回归）
  set.seed(321)
  glm_model <- train(
    x = x_train, 
    y = y_train,
    method = "glmnet",
    family = "binomial",
    trControl = train_control, # 使用十折交叉验证
    tuneGrid = data.frame(
      alpha  = alpha_val,
      lambda = lambda_val
    )
  )
  
  # 6. 生成预测结果并计算指标
  pred <- predict(glm_model, newdata = fold_test)
  cm <- confusionMatrix(pred, fold_test$group)
  
  accuracy <- cm$overall["Accuracy"]
  kappa    <- cm$overall["Kappa"]
  
  # 7. 保存结果
  glm_results <- rbind(glm_results, data.frame(
    alpha    = alpha_val,
    lambda   = lambda_val,
    Accuracy = accuracy,
    Kappa    = kappa
  ))
}

end_time <- Sys.time()
print(end_time - start_time)

# 输出结果并保存
print(glm_results)
write.csv(glm_results, "glm_results_alpha_lambda_cv.csv", row.names = FALSE)

### 补充图Acurracy：GLM 核心参数优化 ## ----
# 把 alpha 设为因子，便于画多条线
glm_results$alpha_f <- factor(glm_results$alpha)

p_glm_acc <- ggplot(glm_results, 
                    aes(x = lambda, y = Accuracy, 
                        group = alpha_f, color = alpha_f)) +
  
  # —— 核心：线和点参数（与你 SVM 完全一致） ——
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # —— lambda 用对数坐标（强烈推荐，期刊标准） ——
  scale_x_log10() +
  
  # —— 配色：IGV 顶刊配色 ——
  scale_color_igv(name = "alpha") + 
  
  # 标签设置（不简写，直接用参数名）
  labs(x = "lambda", 
       y = "Accuracy") +
  
  # —— 基础主题与出版级细节调整（与你前面完全统一） ——
  theme_bw() + 
  theme(
    # 字体
    text = element_text(family = "arial", face = "bold", color = "black"),
    
    # 坐标轴标题
    axis.title.x = element_text(size = 18, margin = ggplot2::margin(t = 15)),
    axis.title.y = element_text(size = 18, margin = ggplot2::margin(r = 15)),
    
    # 刻度文字
    axis.text = element_text(size = 14, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # 去掉网格线
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # 边框与刻度线加粗
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.5),
    axis.ticks = element_line(linewidth = 1.0, color = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    
    # 图例设置
    legend.position = "right",
    legend.title = element_text(size = 14, face = "bold"),
    legend.text = element_text(size = 12),
    legend.key = element_blank(),
    legend.background = element_blank()
  )

# 显示图像
print(p_glm_acc)


### 补充图Kappa：GLM 核心参数优化 ## ----
# 把 alpha 变成 factor，方便分组和图例
glm_results <- glm_results %>%
  mutate(alpha_f = factor(alpha))

# lambda 建议用对数刻度显示

p_glm_single <- ggplot(glm_results, 
                       aes(x = lambda, y = Kappa, 
                           group = alpha_f, color = alpha_f)) +
  
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # lambda 用对数坐标
  scale_x_log10() +
  
  # 图例标题显示 alpha 全名
  scale_color_igv(name = "alpha") + 
  
  # 坐标轴标题显示完整参数名
  labs(x = "lambda", 
       y = "Kappa") +
  
  theme_bw() + 
  theme(
    text = element_text(family = "arial", face = "bold", color = "black"),
    axis.title.x = element_text(size = 18, margin = ggplot2::margin(t = 15)),
    axis.title.y = element_text(size = 18, margin = ggplot2::margin(r = 15)),
    axis.text = element_text(size = 14, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.5),
    axis.ticks = element_line(linewidth = 1.0, color = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    legend.position = "right",
    legend.title = element_text(size = 14, face = "bold"),
    legend.text = element_text(size = 12),
    legend.key = element_blank(),
    legend.background = element_blank()
  )

print(p_glm_single)


#5.Deeplearning##----

library(keras)
library(tidyverse)
library(caret)

set.seed(321)
folds <- createFolds(y = train[,1], k = 10)
lr_grid <- c(1e-4, 3e-4, 5e-4, 1e-3, 3e-3, 5e-3, 1e-2)
batch_grid <- c(8, 16, 32, 64)

dl_results <- data.frame(
  learning_rate = numeric(),
  batch_size    = numeric(),
  Accuracy      = numeric(),
  Kappa         = numeric()
)

lr <- 1e-4
bs <- 8
for(lr in lr_grid){
  for(bs in batch_grid){
    
    message("==== lr = ", lr, " | batch = ", bs, " ====")
    
    acc_vec   <- c()
    kappa_vec <- c()
    
    for(i in 1:10){
      
      fold_test  <- train[folds[[i]], ]
      fold_train <- train[-folds[[i]], ]
      
      colnames(fold_test)  <- gsub("-", "_", colnames(fold_test))
      colnames(fold_train) <- gsub("-", "_", colnames(fold_train))
      
      # -------- X / Y --
      train_x <- as.array(scale(as.matrix(fold_train[, -1])))
      test_x  <- as.array(scale(as.matrix(fold_test[, -1])))
      
      train_y <- as.numeric(fold_train[, 1]) - 1
      test_y  <- as.numeric(fold_test[, 1]) - 1
      
      train_y <- keras::to_categorical(train_y, 2)
      test_y  <- keras::to_categorical(test_y, 2)
      
      train_x[!is.finite(train_x)] <- 0
      test_x[!is.finite(test_x)]   <- 0
      
      # -------- model --
      model <- keras_model_sequential() %>%
        layer_dense(512, activation = "relu",
                    input_shape = dim(train_x)[2]) %>%
        layer_dropout(0.2) %>%
        layer_dense(128, activation = "relu") %>%
        layer_dropout(0.1) %>%
        layer_dense(2, activation = "softmax")
      
      model %>% compile(
        loss = "categorical_crossentropy",
        optimizer = optimizer_adam(learning_rate = lr),
        metrics = "accuracy"
      )
      
      model %>% fit(
        train_x, train_y,
        epochs = 10,
        batch_size = bs,
        verbose = 0
      )
      
      # -------- predict -
      prob <- model %>% predict(test_x)
      pred <- max.col(prob) - 1
      
      cm <- confusionMatrix(
        factor(pred, levels = c(0,1)),
        factor(as.numeric(fold_test[,1]) - 1, levels = c(0,1))
      )
      
      acc_vec   <- c(acc_vec,   cm$overall["Accuracy"])
      kappa_vec <- c(kappa_vec, cm$overall["Kappa"])
    }
    
    # ===== 每组参数汇总 
    dl_results <- rbind(
      dl_results,
      data.frame(
        learning_rate = lr,
        batch_size    = bs,
        Accuracy      = mean(acc_vec),
        Kappa         = mean(kappa_vec)
      )
    )
  }
}
write.csv(dl_results, "Forest.DL.results.learning_rate.batch_size.nocv.csv", row.names = FALSE)

# 设置文件路径
file_path <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/Farmland.DL.results.learning_rate.batch_size.cv.csv"

# 导入 CSV 文件
dl_results <- read.csv(file_path)

# 查看导入的数据
head(dl_results)


## 补充图Accuracy#----
# 先将 learning_rate 和 batch_size 转化为因子变量
dl_results$learning_rate_f <- factor(dl_results$learning_rate)
dl_results$batch_size_f <- factor(dl_results$batch_size)

# 绘制图形

p_dl_results <- ggplot(dl_results, 
                       aes(x = learning_rate_f, 
                           y = Accuracy, 
                           group = batch_size_f, 
                           color = batch_size_f)) + 
  
  # —— 核心：线和点的参数 (0.7 和 2.2)
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # —— 配色：IGV 顶刊配色
  scale_color_igv(name = "batch size") + 
  
  # 标签设置
  labs(x = "learning rate", 
       y = "Accuracy") +
  
  # —— 基础主题与出版级细节调整
  theme_bw() + 
  theme(
    # ❶ 字体大幅加大并加粗 (16pt 以上)
    text = element_text(family = "Arial", face = "bold", color = "black"),
    
    # 坐标轴标题
    axis.title.x = element_text(size = 28, margin = ggplot2::margin(t = 12)),
    axis.title.y = element_text(size = 28, margin = ggplot2::margin(r = 12)),
    
    # 刻度文字
    axis.text = element_text(size = 20, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # ❷ 彻底去掉背景网格线
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # ❸ 统一边框与刻度线的粗细
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.5),  # 面板边框粗细
    axis.ticks = element_line(linewidth = 1.0, color = "black"),  # 坐标轴刻度线粗细
    axis.ticks.length = unit(0.2, "cm"),  # 坐标轴刻度长度
    
    # ❹ 图例设置 (根据需要调整图例)
    legend.position = "right",  # 图例在右边
    legend.title = element_text(size = 22, face = "bold"),
    legend.text = element_text(size = 20),
    legend.key = element_blank(),  # 去掉图例背景色
    legend.background = element_blank()
  )

# 显示图像
print(p_dl_results)

##补充图Kappa##----
# 绘制图形
p_kappa <- ggplot(dl_results, 
                  aes(x = learning_rate_f, y = Kappa, 
                      group = batch_size_f, color = batch_size_f)) +
  
  # —— 核心：线和点的参数 (0.7 和 2.2)
  geom_line(linewidth = 0.7, alpha = 0.8) + 
  geom_point(size = 2.2, stroke = 0.6) +
  
  # —— 配色：采用支持更多颜色的顶刊配色 (IGV)
  scale_color_igv(name = "batch size") + 
  
  # 标签设置
  labs(x = "learning rate", 
       y = "Kappa") +
  
  # —— 基础主题与出版级细节调整
  theme_bw() + 
  theme(
    # ❶ 字体大幅加大并加粗 (16pt 以上)
    text = element_text(family = "Arial", face = "bold", color = "black"),
    
    # 坐标轴标题
    axis.title.x = element_text(size = 28, margin = ggplot2::margin(t = 12)),
    axis.title.y = element_text(size = 28, margin = ggplot2::margin(r = 12)),
    
    # 刻度文字
    axis.text = element_text(size = 20, color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1),
    
    # ❷ 彻底去掉背景网格线
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    # ❸ 边框与刻度线加粗
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 1.5),
    axis.ticks = element_line(linewidth = 1.0, color = "black"),
    axis.ticks.length = unit(0.2, "cm"),
    
    # ❹ 图例设置
    legend.position = "right",  # 图例在右边
    legend.title = element_text(size = 22, face = "bold"),
    legend.text = element_text(size = 20),
    legend.key = element_blank(),  # 去掉图例背景色
    legend.background = element_blank()
  )

# 显示图像
print(p_kappa)



#6补充图train test  AUC##----
model<-randomForest(group~.,data=fold_train,mtry=1200,ntry=1000,nodesize=3, 
                    importance=TRUE, proximity=TRUE)
# 4. 预测概率

# 注意：取第二列（正类概率）
prob_train <- predict(model, fold_train, type = "prob")[,2]
prob_test  <- predict(model, fold_test,  type = "prob")[,2]


# 5. ROC & AUC计算

roc_train <- roc(fold_train$group, prob_train)
roc_test  <- roc(fold_test$group,  prob_test)

auc_train <- auc(roc_train)
auc_test  <- auc(roc_test)


# 6. 整理数据用于ggplot

df_train <- data.frame(
  specificity = roc_train$specificities,
  sensitivity = roc_train$sensitivities,
  Set = "Train"
)

df_test <- data.frame(
  specificity = roc_test$specificities,
  sensitivity = roc_test$sensitivities,
  Set = "Test"
)

df_all <- rbind(df_train, df_test)


# 7. 绘图（论文级风格）

p <- ggplot(df_all, aes(x = 1 - specificity, y = sensitivity, color = Set)) +
  geom_line(size = 1.5) +
  
  annotate("text", x = 0.2, y = 0.3,
           label = paste0("Train AUC: ", round(auc_train, 3)),
           color = "red", size = 6, fontface = "bold",
           hjust = 0) +
  
  annotate("text", x = 0.2, y = 0.2,
           label = paste0("Test AUC: ", round(auc_test, 3)),
           color = "steelblue", size = 6, fontface = "bold",
           hjust = 0) +
  
  labs(
    x = "False positive rate",
    y = "True positive rate"
  ) +
  
  scale_color_manual(values = c("Train" = "red", "Test" = "steelblue")) +
  
  theme_minimal() +
  theme(
    panel.grid = element_blank(),
    axis.line = element_line(color = "black", size = 1),
    axis.ticks.x = element_line(color = "black",size=1),  # 添加横坐标刻度
    axis.ticks.y = element_line(color = "black",size=1),
    axis.text.x = element_text(color = "black", size = 14,face = "bold"),  # x轴刻度标签的颜色和大小),
    axis.text.y = element_text(color = "black", size = 14,face = "bold"),  # y轴刻度标签的颜色和大小 
    axis.text = element_text(size = 16, face = "bold"),
    axis.title.x = element_text(color = "black", size = 18,face = "bold"),  # x轴标题的颜色和大小  
    axis.title.y = element_text(color = "black", size = 18,face = "bold"),
    legend.position = "none",   # 👈 推荐去掉
  )

# 显示图
print(p)



#7补充图Randomforest train test set##----
# 假设您的数据框是 train，第一列是分类标签（Factor类型，如 Biochar/Control）
# 按照您之前的代码逻辑进行划分
set.seed(123)
index.train <- sample(nrow(test), nrow(test) * 0.75)
data_train <- train[index.train, ]
data_test  <- train[-index.train, ]

# 训练随机森林模型
# 注意：一定要让标签是 Factor，这样才能进行分类并获得概率
rf_model <- randomForest(as.factor(data_train[[1]]) ~ ., 
                         data = data_train, 
                         importance = TRUE, 
                         ntree = 500)

# 获取预测概率 (获取属于 "Biochar" 这一类的概率)
# predict(..., type="prob") 会返回一个矩阵，我们取其中一列
train_prob <- predict(rf_model, data_train, type = "prob")[, "Biochar"]
test_prob  <- predict(rf_model, data_test, type = "prob")[, "Biochar"]

# 计算样本的平均强度 (Average Intensity) 作为纵坐标
# 假设强度是数据中所有特征的均值
train_intensity <- rowMeans(data_train[, -1])
test_intensity  <- rowMeans(data_test[, -1])

# 构建绘图用的数据框
plot_df_train <- data.frame(
  prob = train_prob,
  intensity = train_intensity,
  Group = data_train[[1]],
  Set = "A: Bacterial training set"
)

plot_df_test <- data.frame(
  prob = test_prob,
  intensity = test_intensity,
  Group = data_test[[1]],
  Set = "B: Bacterial test set"
)


# 绘制训练集
p1 <- ggplot(plot_df_train, aes(x = prob, y = intensity, color = Group)) +
  geom_point(size = 1.2, alpha = 0.5) +
  
  # 添加分类阈值虚线 (0.5)
  geom_vline(xintercept = 0.5, linetype = "dotted", color = "black") +
  
  scale_color_manual(values = c(
    "Biochar" = "#3B6FB6",
    "Control" = "#D94F3D"
  )) +
  
  labs(
    title = "Randomforest training set",
    x = "Predicted probability",
    y = "Average intensity"
  ) +
  theme(
    plot.title = element_text(
      hjust = 0.5,
      face = "bold",
      size = 14
    )
  )+
  theme_classic(base_size = 14) +   # 整体字体变大
  
  theme(
    # 标题
    plot.title = element_text(
      face = "bold",
      size = 18
    ),
    
    # 坐标轴标题（加粗 + 变大）
    axis.title = element_text(
      size = 16,
      face = "bold"
    ),
    
    # 坐标刻度（加粗）
    axis.text = element_text(
      size = 14,
      face = "bold",
      color = "black"
    ),
    
    # 坐标轴线（加粗）
    axis.line = element_line(
      linewidth = 1,
      color = "black"
    ),
    
    # 刻度线（很多人忽略，这个很关键）
    axis.ticks = element_line(
      linewidth = 0.8,
      color = "black"
    ),
    
    panel.grid = element_blank(),
    
    # 图例
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(
      size = 14,
      face = "bold"
    ),
    
    legend.key.size = unit(0.5, "cm"),
    
    # 边距（记得用 ggplot2::margin 防冲突）
    plot.margin = ggplot2::margin(6, 8, 6, 6)
  )

print(p1)

# 绘制测试集
p2 <- ggplot(plot_df_test, aes(x = prob, y = intensity, color = Group)) +
  geom_point(size = 1.2, alpha = 0.5) +
  
  geom_vline(xintercept = 0.5, linetype = "dotted", color = "black") +
  
  scale_color_manual(values = c(
    "Biochar" = "#3B6FB6",
    "Control" = "#D94F3D"
  )) +
  
  labs(
    title = "Randomforest test set",
    x = "Predicted probability",
    y = "Average intensity"
  ) +
  
  theme_classic(base_size = 14) +
  
  theme(
    plot.title = element_text(
      hjust = 0.5,   # 居中
      face = "bold",
      size = 18
    ),
    
    axis.title = element_text(size = 16, face = "bold"),
    
    axis.text = element_text(size = 14, face = "bold", color = "black"),
    
    axis.line = element_line(linewidth = 1, color = "black"),
    
    axis.ticks = element_line(linewidth = 0.8, color = "black"),
    
    panel.grid = element_blank(),
    
    legend.position = "top",
    legend.title = element_blank(),
    legend.text = element_text(size = 14, face = "bold"),
    
    legend.key.size = unit(0.5, "cm"),
    
    plot.margin = ggplot2::margin(6, 8, 6, 6)
  )

print(p2)

#8.alpha多样性##----
#画alpha多样性图时要先运行一下1_OTU_parameter.R这个脚本。
alppath = paste(otupath,"/alpha/",sep = "")
dir.create(alppath)
# source("../micro_Big/alpha-diversity.R")

#---多种指标alpha多样性分析加出图-标记显著性
source("micro_Big/alpha-diversity.R")
index = c("Shannon","Inv_Simpson","Pielou_evenness","Simpson_evenness" ,"Richness" ,"Chao1","ACE" )
#--多种组合alpha分析和差异分析出图
alp = alpha(ps = ps,inde="Shannon",group = "Group",Plot = TRUE )
index= alp
head(index)

library(ggplot2)
library(ggpubr)
library(ggsignif)  # 用于拼图

# 确保Group为因子
index$Group <- factor(index$Group, levels = c("Biochar","Control"))

# ---------- Simpson_evenness 指数 ----------
# 预先计算 Y 轴的最大值，以便动态设置横线高度
max_y <- max(index$Simpson_evenness, na.rm = TRUE)

p_simpson <- ggplot(index, aes(x = Group, y = Simpson_evenness, fill = Group)) +
  # 1. 基础图层
  geom_violin(trim = FALSE, alpha = 0.5, color = "black", linewidth = 0.8) +
  geom_boxplot(width = 0.2, outlier.shape = NA, linewidth = 0.8, color = "black") +
  
  # 2. 优化后的显著性横线标注 (解决连接重合问题)
  geom_signif(
    comparisons = list(c("Biochar", "Control")),
    map_signif_level = TRUE,
    textsize = 6,
    vjust = 0.2,               # 星号相对于横线的向上偏移量
    y_position = max_y * 1.1,  # 手动设置横线高度为最大值的 1.1 倍，确保完全悬空
    tip_length = 0.03,         # 增加两端小勾的长度，使其更清晰
    size = 0.8,
    color = "black"
  ) +
  
  # 3. 颜色与标签
  scale_fill_manual(values = c("Control" = "#E15759", "Biochar" = "#4E79A7")) +
  labs(title = "Simpson_evenness", y = "", x = "") + # 建议加上 Y 轴名称
  
  # 4. 主题设置与坐标轴优化
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.2))) + # 增加顶部留白，防止标注被切掉
  theme_classic(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 18),
    axis.title.y = element_text(face = "bold", size = 16),
    axis.text = element_text(face = "bold", size = 14, color = "black"),
    axis.line = element_line(linewidth = 1, color = "black"),
    axis.ticks = element_line(linewidth = 0.8, color = "black"),
    legend.position = "none",
    plot.margin = ggplot2::margin(10, 10, 10, 10)
  )

print(p_simpson)
# ---------- Shannon 指数 ----------
# 预先计算最大值并设置悬浮高度 (例如最大值的 1.15 倍)
max_y_shannon <- max(index$Shannon, na.rm = TRUE)
shannon_line_height <- max_y_shannon * 1.15 

p_shannon <- ggplot(index, aes(x = Group, y = Shannon, fill = Group)) +
  geom_violin(trim = FALSE, alpha = 0.5, color = "black", linewidth = 0.8) +
  geom_boxplot(width = 0.2, outlier.shape = NA, linewidth = 0.8, color = "black") +
  
  # 绘制悬空的 ns 横线
  geom_signif(
    comparisons = list(c("Biochar", "Control")),
    map_signif_level = function(p) { if(p > 0.05) return("ns") else return("***") },
    textsize = 6,
    vjust = -0.2,                  # 将文字微调至横线上方一点
    y_position = shannon_line_height, # 强制横线处于高位
    tip_length = 0.03,
    size = 0.8,
    color = "black"
  ) +
  
  scale_fill_manual(values = c("Control" = "#E15759", "Biochar" = "#4E79A7")) +
  labs(title = "Shannon", y = "", x = "") +
  
  # 关键：使用 expand 为顶部留出 25% 的空间，防止横线被切掉
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.25))) + 
  theme_classic(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 18),
    axis.title.y = element_text(face = "bold", size = 16),
    axis.text = element_text(face = "bold", size = 14, color = "black"),
    axis.line = element_line(linewidth = 1, color = "black"),
    axis.ticks = element_line(linewidth = 0.8, color = "black"),
    legend.position = "none"
  )

print(p_shannon)

#9.beta-diversity多样性##----
source("micro_Big/BetaDiv.R")
source("micro_Big/MicroTest.R")
source("micro_Big/pairMicroTest.R")
# 1. 准备数据
#methodlist = c("NMDS","PCoA", "PCA")
method <- "PCoA"
result = BetaDiv(ps = ps, group = "Group", dist = "bray",
                 method = method, Micromet = "adonis",
                 pvalue.cutoff = 0.05,
                 pair = F)

plot_data <- result[[2]]

# 2. 提取 Adonis 统计结果 (假设 result[[1]] 的标题或属性中包含这些信息)
# 如果 result 对象结构标准，可以直接尝试提取，或者手动输入您图中看到的数值
# 标准的数学格式标签准备
r_square <- 0.019
p_value <- 0.001
# 注意：这里不再加 bold，顶刊标题通常不加粗数学符号
stat_label <- bquote(Adonis:R^2 == .(r_square)*","~P == .(p_value))

# 绘图
pcoa_top_label <- ggplot(result[[2]], aes(x = x, y = y, fill = Group, color = Group)) +
  stat_ellipse(aes(color = Group), linewidth = 0.4, linetype = "dashed", show.legend = FALSE) +
  geom_point(shape = 21, size = 1.8, alpha = 0.4, color = "grey90", stroke = 0.1) +
  
  # 配色与标签
  scale_fill_manual(values = c("Biochar" = "#2E5A88", "Control" = "#C0392B")) +
  scale_color_manual(values = c("Biochar" = "#2E5A88", "Control" = "#C0392B")) +
  
  # 关键修改：将统计结果作为图形标题 (会显示在最上方空白处)
  labs(title = stat_label,
       x = "PCoA 1 (29.29%)", y = "PCoA 2 (22.05%)", fill = "Group") +
  
  theme_test() + 
  theme(
    aspect.ratio = 1,
    text = element_text(family = "sans", size = 7), # Nature一般要求 5-7pt
    axis.title = element_text(size = 8, face = "bold"),
    axis.text = element_text(size = 7, color = "black"),
    # 标题样式精修
    plot.title = element_text(size = 8, hjust = 0, margin = margin(b = 5)),
    panel.border = element_rect(fill = NA, linewidth = 0.7),
    legend.position = "right",
    legend.title = element_text(size = 8, face = "bold"),
    legend.text = element_text(size = 7),
    legend.key.size = unit(0.3, "cm")
  )

print(pcoa_top_label)



#---10.物种组成展示#---------
source("micro_Big/barMainplot.R")
barpath = paste(otupath,"/Microbial_composition/",sep = "")
dir.create(barpath)
ps.ExcludeUnassigned <- ps
# 提取 OTU 表
otu_data <- otu_table(ps.ExcludeUnassigned)
# 检查行名，确保 "Unassigned" 是否存在
rownames(otu_data)
# 过滤掉行名为 "Unassigned" 的行
otu_data_filtered <- otu_data[, colnames(otu_data) != "Unassigned"]
# 将过滤后的 OTU 表更新回 phyloseq 对象
otu_table(ps.ExcludeUnassigned) <- otu_data_filtered
ps.ExcludeUnassigned
phyloseq::rank_names(ps.ExcludeUnassigned)

j <- "Phylum"
result = barMainplot(ps =ps.ExcludeUnassigned  ,
                     j = j,
                     # axis_ord = axis_order,
                     label = FALSE,
                     sd = FALSE,
                     Top = Top)


# 1. 关键步骤：先按组和物种求平均丰度，解决“全黑”问题
df_sum <- result[[2]] %>%
  group_by(Group, aa) %>%
  summarise(Abundance = mean(Abundance, na.rm = TRUE)) %>%
  ungroup()

# 2. 对物种进行排序（丰度最高的排在最下面，视觉效果最好）
df_sum <- df_sum %>%
  group_by(aa) %>%
  mutate(total_mean = mean(Abundance)) %>%
  ungroup() %>%
  mutate(aa = reorder(aa, total_mean)) 

# 3. 定义 Nature 风格色板
my_colors <- c(
  "#E64B35FF", "#4DBBD5FF", "#00A087FF", "#3C3C3CFF", 
  "#F39B7FFF", "#8491B0FF", "#91D1C2FF", "#DC0000FF", 
  "#7E6148FF", "#B09C85FF", "#BC3C29FF", "#0072B5FF", 
  "#E18727FF", "#20854EFF"
)

# 4. 绘图
p_taxa_final <- ggplot(df_sum, aes(x = Group, y = Abundance, fill = aa)) +
  # 使用 position = "fill" 强制两根柱子高度绝对对齐
  # 去掉 geom_bar 里的 color="black" 或调细线宽，防止大黑边
  geom_bar(stat = "identity", position = "fill", width = 0.7, 
           color = "black", linewidth = 0.2) + 
  
  scale_fill_manual(values = my_colors) +
  
  # 设置 Y 轴为百分比格式
  scale_y_continuous(labels = c("0", "25", "50", "75", "100"), 
                     expand = c(0, 0)) +
  
  labs(x = "", y = "Relative abundance (%)", fill = "Phylum") +
  
  # 顶刊主题
  theme_classic() +
  theme(
    text = element_text(family = "sans", size = 8),
    axis.title.y = element_text(size = 10, face = "bold"),
    axis.text = element_text(size = 9, color = "black", face = "bold"),
    axis.line = element_line(linewidth = 0.8, color = "black"),
    legend.position = "right",
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8, face = "italic"),
    legend.key.size = unit(0.3, "cm")
  )

print(p_taxa_final)




#---11.Co-occurrence_Network#---------


# 1. 环境准备与 Top 10 颜色映射定义

library(igraph)
library(ggraph)
library(tidygraph)
library(ggplot2)
library(phyloseq)
library(ggClusterNet)
library(patchwork)
library(ggsci) # 引入学术色板包

# 动态获取前 10 个门类
top10_info <- ps %>% 
  tax_table() %>% 
  as.data.frame() %>% 
  count(Phylum, sort = TRUE) %>% 
  slice_max(n, n = 10)

top10_names <- as.character(top10_info$Phylum)

# 定义颜色映射：确保 Top 10 + "Other" 颜色在两图中完全统一
# 使用 npg 色板并手动扩展一个颜色给 "Other"
my_colors <- setNames(c(pal_npg()(10), "#B09C85FF"), c(top10_names, "Other"))

# 处理原始数据：将非 Top 10 的全部归为 "Other"
tax_df <- as.data.frame(tax_table(ps))
tax_df$Phylum <- ifelse(tax_df$Phylum %in% top10_names, tax_df$Phylum, "Other")
new_tax_table <- tax_table(as.matrix(tax_df))

ps_filtered <- ps
tax_table(ps_filtered) <- new_tax_table


# 2. 核心绘图函数 (Nature 出版级优化)

draw_top10_sphere_net <- function(ps_sub, group_label) {
  
  set.seed(123)
  res = ggClusterNet::network.2(ps = ps_sub, N = 500, big = TRUE, maxnode = 5,
                                layout_net = "model_maptree2", r.threshold = 0.6,
                                p.threshold = 0.05, label = FALSE, zipi = FALSE)
  
  g <- graph_from_adjacency_matrix(res[[4]], mode = "undirected", weighted = TRUE, diag = FALSE)
  g <- igraph::delete.vertices(g, V(g)[igraph::degree(g) == 0]) 
  
  # 计算统计量
  edge_df <- as.data.frame(igraph::as_data_frame(g, what = "edges"))
  total_edges <- nrow(edge_df)
  pos_pct <- round(sum(edge_df$weight > 0) / total_edges * 100, 2)
  neg_pct <- round(100 - pos_pct, 2)
  
  stats_info <- paste0("Nodes: ", vcount(g), " | Edges: ", total_edges, "\n",
                       "Positive: ", pos_pct, "% | Negative: ", neg_pct, "%")
  
  tg <- as_tbl_graph(g) %>%
    activate(nodes) %>%
    mutate(degree = centrality_degree(),
           # 确保 Phylum 因子顺序一致，防止图例乱序
           Phylum = factor(ifelse(name %in% rownames(tax_df), as.character(tax_df[name, "Phylum"]), "Other"),
                           levels = c(top10_names, "Other"))) %>%
    activate(edges) %>%
    mutate(Relation = ifelse(weight > 0, "Positive", "Negative"),
           abs_weight = abs(weight))
  
  #若贡献网络看着不圆，可以将layout参数"fr"换成“kk”,他们的节点和边是不会变的。
  p <- ggraph(tg, layout = "fr", weights = abs_weight, niter = 2000) + 
    geom_edge_link(aes(color = Relation), alpha = 0.25, edge_width = 0.5) +
    geom_node_point(aes(size = degree, fill = Phylum), shape = 21, color = "white", stroke = 0.4) +
    
    scale_edge_color_manual(values = c("Positive" = "#E64B35FF", "Negative" = "#4DBBD5FF")) +
    # 应用统一的 Top 10 颜色
    scale_fill_manual(values = my_colors, drop = FALSE) + 
    scale_size_continuous(range = c(2, 10), limits = c(0, 60), name = "Degree") +
    
    coord_fixed() + 
    labs(subtitle = stats_info, caption = group_label) + 
    theme_graph(base_family = "sans") +
    theme(
      plot.subtitle = element_text(size = 14, face = "bold", hjust = 0.5, lineheight = 1.1, color = "black"),
      plot.caption = element_text(size = 22, face = "bold", hjust = 0.5, margin = margin(t = 20)),
      legend.title = element_text(size = 15, face = "bold"),
      legend.text = element_text(size = 13, face = "bold"),
      legend.position = "right"
    )
  
  return(p)
}


# 3. 分组执行与导出

ps_con <- subset_samples(ps_filtered, Group == "Control") %>% prune_taxa(taxa_sums(.) > 0, .)
ps_bio <- subset_samples(ps_filtered, Group == "Biochar") %>% prune_taxa(taxa_sums(.) > 0, .)

p_con <- draw_top10_sphere_net(ps_con, "Control")
p_bio <- draw_top10_sphere_net(ps_bio, "Biochar")

# 合并并对齐图例
final_plot <- p_bio + p_con + 
  plot_layout(guides = 'collect') & 
  theme(legend.position = "right")

# 4. 导出出版级高清大图

# 推荐使用 PDF 或 TIFF 格式，这是顶刊要求的矢量或高 DPI 格式
ggsave("Microbial_Network_Nature_Style.pdf", 
       final_plot, 
       width = 16,     # 适当增加宽度以适应大图组合
       height = 9, 
       device = cairo_pdf, # 使用 cairo 渲染以获得更好的字体兼容性
       limitsize = FALSE)

# 如果需要 PNG 预览，设置高 DPI
ggsave("Microbial_Network_Nature_Style.png", 
       final_plot, 
       width = 16, 
       height = 9, 
       dpi = 600)

print("生成完成！图片已按出版级要求优化加粗。")

