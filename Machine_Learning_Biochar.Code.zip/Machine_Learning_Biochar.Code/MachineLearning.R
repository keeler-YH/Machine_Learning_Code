#---多种机器学习#-----------

library(ggClusterNet)
library(phyloseq)
library(tidyverse)


library(randomForest)
library(caret)
library(ROCR) ##用于计算ROC
library(e1071)

MLpath <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/biochar/bac/new/Farmland/ML"
ps0 = base::readRDS("./biochar/bac/new/ps.orig.unoise3.bac.Farmland.Genus.rds")
ps0
map = ps0 %>% sample_data()
dim(map)
input_file.bac <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/1_1_ID_to_listFile/download/bac_metadata_Farmland.filtered.soil.csv"
# 导入CSV文件
bac_metadata <- read.csv(input_file.bac, header = T)
bac_metadata$Group <- trimws(bac_metadata$Group)
match_indices <- match(map$ID, bac_metadata$Sample.names)
map$Group <- bac_metadata[match_indices,11]
map$assid %>% unique()
#map$Group = c(rep("Biochar",672),rep("Control",500))
#map$Group = as.factor(map$Group)
sample_data(ps0) = map
#  去除空缺值--空缺值来源合并样本
otu = ps0 %>% vegan_otu() %>% t() 
otu[is.na(otu)] = 0
#标准化
otu <- data.frame(apply(otu,2,function(x) x/sum(x))*100,stringsAsFactors = FALSE)
otu_table(ps0) = otu_table(as.matrix(otu),taxa_are_rows = TRUE)
#-分组都是两两比较
i = 1
map= sample_data(ps0)
head(map)
id.g = map$Group %>% unique() %>% as.character() %>% combn(2)
ps.cs = ps0 %>% subset_samples.wt("Group" ,id.g[,i])

#1.随机森林#------
map = as.data.frame(phyloseq::sample_data(ps.cs))
otutab = as.data.frame(t(ggClusterNet::vegan_otu(ps.cs)))
colnames(otutab) <- gsub("-","_",colnames(otutab)) 
test = as.data.frame(t(otutab))
test$group = factor(map$Group)
test <- test[, colnames(test) != "Unassigned"]
colnames(test) = paste("OTU",colnames(test),sep = "")

colnames(test) <- gsub("-","_",colnames(test))
colnames(test) <- gsub("[/]","_",colnames(test))
colnames(test) <- gsub("[(]","_",colnames(test))
colnames(test) <- gsub("[)]","_",colnames(test))
colnames(test) <- gsub("[:]","_",colnames(test))
colnames(test) <- gsub("[[]","",colnames(test))
colnames(test) <- gsub("[]]","_",colnames(test))
colnames(test) <- gsub("[#]","_",colnames(test))
colnames(test) <- gsub("[+]","_",colnames(test))
colnames(test) <- gsub(" ","_",colnames(test))

test = dplyr::select(test,OTUgroup,everything())
train = test



#set.seed(123)
#select_train <- sample(4575, 4575*0.7)
#otu_train <- train[select_train, ]
#otu_test <- train[-select_train, ]
#otu_train.forest <- randomForest(OTUgroup~., data = otu_train, importance = TRUE)
#otu_train.forest
set.seed(0)
folds <- createFolds(y=test[,1],k=10)
AUC =c()
max=0
num=0
fc.rf<-c()#fc 为测试数据真实分组信息
mod_pre.rf<-c()
i = 1
for(i in 1:10){
  fold_test<-train[folds[[i]],]
  fold_train<-train[-folds[[i]],]
  colnames(fold_test) <- gsub("-","_",colnames(fold_test)) 
  colnames(fold_train) <- gsub("-","_",colnames(fold_train)) 
  model<-randomForest(OTUgroup~.,data=fold_train,mtry=1200,ntry=1000,nodesize=3, 
                      importance=TRUE, proximity=TRUE)
  model
  #plot(fold_train$OTUgroup, plant_predict, main = '训练集',
   #    xlab = 'Type', ylab = 'Predict')
  #abline(1, 1)
  model_pre<-predict(model,newdata = fold_test,type="prob")
  fc.rf<-append(fc.rf,fold_test$OTUgroup)
  mod_pre.rf<-append(mod_pre.rf,model_pre[,2])
}


#- pick data and plot
pred.rf <- prediction(mod_pre.rf, fc.rf)  
perf.rf <- performance(pred.rf,"tpr","fpr") 
x.rf <- unlist(perf.rf@x.values)  ##提取x值
y.rf <- unlist(perf.rf@y.values)
plotdata.rf <- data.frame(x.rf,y.rf) 
names(plotdata.rf) <- c("x", "y")
AUC[1] = paste("rf AUC:",round(performance(pred.rf,'auc')@y.values[[1]],3),sep = " ")
value.AUC <- round(performance(pred.rf,'auc')@y.values[[1]],3)
value.AUC <- sprintf("%.3f", value.AUC)
value.AUC
head(plotdata.rf)
g0 <- ggplot(plotdata.rf) + 
  geom_path(aes(x = x.rf, y = y.rf, colour = x.rf), size = 1.5, color = "red") + 
  labs(x = "False positive rate", y = "True positive rate") +  # 修正拼写错误
  annotate("text", x = 0.45, y = 0.1, label = paste("RandomForest AUC:", value.AUC, sep = ""), hjust = 0,fontface  = "bold") +
  geom_segment(aes(x = 0.4, y = 0.1, xend = 0.45, yend = 0.1),
               linetype = "solid", color = "red", size = 1) +
  theme_minimal() +  # 使用简约主题
  theme(panel.grid.major = element_blank(),  # 去掉主要网格线
        panel.grid.minor = element_blank(), # 去掉次要网格线
        axis.line.x = element_line(color = "black",size=1),  # 添加横坐标线
        axis.line.y = element_line(color = "black",size=1),  # 添加纵坐标线
        axis.ticks.x = element_line(color = "black",size=1),  # 添加横坐标刻度
        axis.ticks.y = element_line(color = "black",size=1),
        axis.text.x = element_text(color = "black", size = 14,face = "bold"),  # x轴刻度标签的颜色和大小),
        axis.text.y = element_text(color = "black", size = 14,face = "bold"),  # y轴刻度标签的颜色和大小  
        axis.title.x = element_text(color = "black", size = 14,face = "bold"),  # x轴标题的颜色和大小  
        axis.title.y = element_text(color = "black", size = 14,face = "bold"))  # y轴标题的颜色和大小  )  # 添加纵坐标刻度 
g0

df.rf <- data.frame( mod_pre.rf,fc.rf)
mod_pre_factor <- factor(ifelse(df.rf$mod_pre.rf >= 0.5, "Control","Biochar"), levels = levels(df.rf$fc.rf))
fc_factor <- factor(df.rf$fc.rf)
conf <- confusionMatrix(mod_pre_factor, fc_factor)
conf
header.tem <- c("method",names(conf$overall),names(conf$byClass),"AUC")
value.tem <- c("RandomForest",as.numeric(conf$overall),as.numeric(conf$byClass),value.AUC)
res.rf <- rbind(header.tem,value.tem)
res.rf

#MLpath <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/Result.Big.Amplicon2/Genus/ML"
#FileName <- paste(MLpath,"/res.rf.csv", sep = "")
#write.csv(res.rf,FileName,row.names = FALSE, col.names = FALSE)

#2.XGBoost#-----
library(xgboost)
max=0
num=0
fc.xgb <- c()
mod_pre.xgb <- c()
i = 1
for(i in 1:10){
  fold_test<-train[folds[[i]],]
  fold_train<-train[-folds[[i]],]
  train_x=as.matrix(fold_train[,-1])
  train_y1=fold_train[,1]
  train_y <- ifelse(train_y1 == "Biochar", 1, 0)
  
  test_x=as.matrix(fold_test[,-1])
  test_y1=fold_test[,1]
  test_y <- ifelse(test_y1 == "Biochar", 1, 0)
  
  train_x <- scale(train_x)
  test_x <- scale(test_x)
  model.xgb <- xgboost(data = train_x, label = train_y,
                       nrounds = 500, objective = "binary:logistic")
  model.xgb
  model_pre <- predict(model.xgb, newdata = test_x)
  fc.xgb <- append(fc.xgb,test_y)
  mod_pre.xgb<-append(mod_pre.xgb,model_pre)
}
pred.x <- prediction(as.numeric(mod_pre.xgb), as.numeric(fc.xgb))
perf.x <- performance(pred.x, "tpr", "fpr")
x.x <- unlist(perf.x@x.values)  
y.x <- unlist(perf.x@y.values)
plotdata.xgb <- data.frame(x.x,y.x) 
names(plotdata.xgb) <- c("x", "y")
AUC[2] = paste("xgboost AUC:",round(performance(pred.x,'auc')@y.values[[1]],3),sep = " ")
value.AUC.xgb <- round(performance(pred.x,'auc')@y.values[[1]],3)
value.AUC.xgb <- sprintf("%.3f", value.AUC.xgb)
value.AUC.xgb
g1 <- g0 + 
  geom_path(data = plotdata.xgb,aes(x = x.x, y = y.x, colour = x.x), size=1.5,color = "green") + 
  labs(x = "False positive rate", y = "Ture positive rate") +
  annotate("text", x=0.6, y=0.15, label=paste("XGBoost AUC:",value.AUC.xgb,sep = ""),hjust=0,fontface  = "bold")+
  geom_segment(aes(x = 0.55, y = 0.15, xend = 0.6, yend = 0.15),
               linetype = "solid", color = "green", size = 1)

g1
pred_factor <- factor(ifelse(mod_pre.xgb >= 0.5, 1, 0))  # 根据阈值转换为因子变量
test_y_factor <- factor(fc.xgb)
# 计算混淆矩阵
conf <- confusionMatrix(pred_factor, test_y_factor)
conf
header.tem <- c("method",names(conf$overall),names(conf$byClass),"AUC")
value.tem <- c("XGBoost",as.numeric(conf$overall),as.numeric(conf$byClass),value.AUC.xgb)
res.xgb <- rbind(header.tem,value.tem)
res.xgb

#3.GLM(广义线性模型)#---------
max=0
num=0
fc.g<- c()
mod_pre.g<- c()
for(i in 1:10){
  fold_test<-train[folds[[i]],]
  fold_train<-train[-folds[[i]],]
  model<-glm(OTUgroup~.,family='binomial',data=fold_train)
  model
  model_pre<-predict(model,newdata=fold_test,type="response")
  model_pre
  
  fc.g<-append(fc.g,fold_test$OTUgroup)
  mod_pre.g<-append(mod_pre.g,as.numeric(model_pre))
}

pred.g <- prediction(mod_pre.g, fc.g)  
perf.g <- performance(pred.g,"tpr","fpr") 
x.g <- unlist(perf.g@x.values)  ##提取x值
y.g <- unlist(perf.g@y.values)
plotdata.g <- data.frame(x.g,y.g) 
names(plotdata.g) <- c("x", "y")
AUC[3] = paste("GLM AUC:",round(performance(pred.g,'auc')@y.values[[1]],3),sep = " ")
value.AUC.g <- round(performance(pred.g,'auc')@y.values[[1]],3)
value.AUC.g <- sprintf("%.3f", value.AUC.g)
value.AUC.g

g2 <- g1 + 
  geom_path(data = plotdata.g,aes(x = x.g, y = y.g, colour = x.g), size=1.5,color = "black") + 
  labs(x = "False positive rate", y = "Ture positive rate") +
  annotate("text", x=0.6, y=0.1, label=paste("Generalized Linear Model AUC:",value.AUC.g,sep = ""),hjust=0,fontface  = "bold")+
  geom_segment(aes(x = 0.55, y = 0.1, xend = 0.6, yend = 0.1),
               linetype = "solid", color = "black", size = 1)

g2

mod_pre.g_factor <- factor(ifelse(mod_pre.g > 0.5, "Biochar", "Control"), levels = levels(fc.g))
conf <- confusionMatrix(mod_pre.g_factor, fc.g)
print(conf)
header.tem <- c("method",names(conf$overall),names(conf$byClass),"AUC")
value.tem <- c("Generalized Linear Model",as.numeric(conf$overall),as.numeric(conf$byClass),value.AUC.g)
res.g <- rbind(header.tem,value.tem)
res.g


#4.svm(支持向量机)#------
max=0
num=0
fc.s <- c()
mod_pre.s <- c()
i = 1
for(i in 1:10){
  fold_test<-train[folds[[i]],]
  # head(fold_test)
  fold_train<-train[-folds[[i]],]
  model<-svm(OTUgroup~.,data=fold_train,sigma=0.2,cost=3,probability=TRUE)
  model
  model_pre<-predict(model,newdata = fold_test,decision.values = TRUE, probability = TRUE)
  fc.s <- append(fc.s,as.numeric(fold_test$OTUgroup))
  mod_pre.s<-append(mod_pre.s,as.numeric(attr(model_pre, "probabilities")[,2]))
}

pred.s <- prediction(mod_pre.s, fc.s)
perf.s <- performance(pred.s,"tpr","fpr") 
x.s <- unlist(perf.s@x.values)  
y.s <- unlist(perf.s@y.values)
plotdata.s <- data.frame(x.s,y.s) 
names(plotdata.s) <- c("x", "y")
AUC[4] = paste("svm AUC:",round(performance(pred.s,'auc')@y.values[[1]],3),sep = " ")
value.AUC.s <- round(performance(pred.s,'auc')@y.values[[1]],3)
value.AUC.s <- sprintf("%.3f", value.AUC.s)
value.AUC.s
g3 <- g0 + 
  geom_path(data = plotdata.s,aes(x = x.s, y = y.s, colour = x.s), size=1.5,color = "blue") + 
  # labs(x = "False positive rate", y = "Ture positive rate") +
  annotate("text", x=0.45, y=0.05, label=paste("Support Vector Machine AUC:",value.AUC.s,sep = ""),hjust=0,fontface  = "bold")+
  geom_segment(aes(x = 0.4, y = 0.05, xend = 0.45, yend = 0.05),
               linetype = "solid", color = "blue", size = 1)
g3
df.s <- data.frame( mod_pre.s,fc.s)
df.s$fc.s <- factor(df.s$fc.s)
mod_pre_factor <- factor(ifelse(df.s$mod_pre.s >= 0.5, 2,1), levels = levels(df.s$fc.s))
#df.s$fc.s <- factor(df.s$fc.s)
conf <- confusionMatrix(mod_pre_factor,df.s$fc.s)
conf
header.tem <- c("method",names(conf$overall),names(conf$byClass),"AUC")
value.tem <- c("Support Vector Machine",as.numeric(conf$overall),as.numeric(conf$byClass),value.AUC.s)
res.s <- rbind(header.tem,value.tem)
res.s
#MLpath <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/Result.Big.Amplicon2/Genus/ML"
#FileName <- paste(MLpath,"/res.rf.csv", sep = "")
#write.csv(res.rf,FileName,row.names = FALSE, col.names = FALSE)



#5.深度学习-#-----
# 参考：https://mp.weixin.qq.com/s/_8i3wlDKzSSZ1n2kP1l1QA
# 参考（使用）：https://mp.weixin.qq.com/s/KUGMCfhAp28B4yTT0u1yQQ
# install("keras3")
library(keras)
#library(keras3)
library(tidyverse)
fc.dl <- c()
mod_pre.dl <- c()
i = 1
for(i in 1:10){
  fold_test<-train[folds[[i]],]
  fold_train<-train[-folds[[i]],]
  colnames(fold_test) <- gsub("-","_",colnames(fold_test)) 
  colnames(fold_train) <- gsub("-","_",colnames(fold_train)) 
  #定义训练集和测试集的自变量集和因变量,这里0代表“Biochar”,1代表“Control”
  train_x <- as.array(scale(as.matrix(fold_train[, -1])))
  test_x  <- as.array(scale(as.matrix(fold_test[, -1])))
  
  train_y <- as.numeric(fold_train[, 1]) - 1
  test_y  <- as.numeric(fold_test[, 1]) - 1
  
  train_y <- keras::to_categorical(train_y, 2)
  test_y  <- keras::to_categorical(test_y, 2)
  
  train_x[!is.finite(train_x)] <- 0
  test_x[!is.finite(test_x)]   <- 0
  #统一把所有非有限值替换为 0
  #test_x[!is.finite(test_x)] <- 0
  #train_x[!is.finite(train_x)] <- 0
  #定义keras序列模型
  model=keras_model_sequential()
  #为模型设置一个输入层(256个神经元)、一个隐蔽层(128个神经元)以及一个输出层(2个神经元)
  dim(train_x)[2]
  model %>% 
    layer_dense(units=512,activation='relu',input_shape=dim(train_x)[2]) %>% 
    layer_dropout(rate=0.2) %>% 
    layer_dense(units=128,activation='relu') %>%
    layer_dropout(rate=0.1) %>%
    layer_dense(units=2,activation='softmax')
  #对模型进行编译
  model %>%
    compile(
      loss='categorical_crossentropy',
      optimizer = optimizer_adam(learning_rate = 0.0005),
      metrics=c('accuracy'))
  #拟合模型
  history=model %>% fit(train_x,train_y,epochs=10,batch_size = 16)
  #查看模型的拟合过程及结果
  history;plot(history)
  model %>% evaluate(test_x,test_y)
  model_pre <- model %>% predict(test_x)
  model_pre
  predicted_classes <- ifelse(model_pre[, 1] >= 0.5, 0, 1)
  
  fc.dl<-append(fc.dl,fold_test$OTUgroup)
  mod_pre.dl<-append(mod_pre.dl,as.numeric(predicted_classes))

}
pred.d <- prediction(mod_pre.dl, fc.dl)  
perf.d <- performance(pred.d,"tpr","fpr") 
x.d <- unlist(perf.d@x.values)  ##提取x值
y.d <- unlist(perf.d@y.values)
plotdata.dl <- data.frame(x.d,y.d) 
names(plotdata.dl) <- c("x", "y")
AUC[5] = paste("DL AUC:",round(performance(pred.d,'auc')@y.values[[1]],3),sep = " ")
value.AUC.dl <- round(performance(pred.d,'auc')@y.values[[1]],3)
value.AUC.dl <- sprintf("%.3f", value.AUC.dl)
value.AUC.dl
g4 <- g3 + 
  geom_path(data = plotdata.dl,aes(x = x.d, y = y.d, colour = x.d), size=1.5,color = "yellow") + 
  labs(x = "False positive rate", y = "Ture positive rate") +
  annotate("text", x=0.45, y=0, label=paste("Deep Learning AUC:",value.AUC.dl,sep = ""),hjust=0,fontface  = "bold")+
  geom_segment(aes(x = 0.4, y = 0, xend = 0.45, yend = 0),
               linetype = "solid", color = "yellow", size = 1)
g4
# 将 mod_pre.dl 和 fc.dl 转换为因子变量，并设置相同的水平
mod_pre_factor <- factor(ifelse(mod_pre.dl == 0, "Biochar", "Control"), 
                         levels = levels(fc.dl))
fc_factor <- factor(fc.dl)
# 计算混淆矩阵
conf <- confusionMatrix(mod_pre_factor, fc_factor)
print(conf)
header.tem <- c("method",names(conf$overall),names(conf$byClass),"AUC")
value.tem <- c("Deep Learning",as.numeric(conf$overall),as.numeric(conf$byClass),value.AUC.dl)
res.dl <- rbind(header.tem,value.tem)
res.dl

#res.all <-rbind(res.rf,res.xgb[2,],res.g[2,],res.s[2,],res.dl[2,])
res.all <-rbind(res.rf,res.s[2,],res.dl[2,])
#MLpath <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/Result.Big.Amplicon3/Genus.Farmland/ML"
fs::dir_create(MLpath)
FileName <- paste(MLpath,"/res.unoise3.Species.Forest.csv", sep = "")
write.csv(res.all,FileName,row.names = FALSE, col.names = FALSE)


#MLpath <- "D:/bioinformatics/众人拾柴火焰高第一期/Big_data_amplicon_pipeline/4_ps.to.data.mining/Result.Big.Amplicon2/Genus/ML"
Kingdom <- read.table(file.path(MLpath, "res.unoise3.Kingdom.Farmland.csv"), 
                      header = TRUE, sep = ",", stringsAsFactors = FALSE)
Phylum <- read.table(file.path(MLpath, "res.unoise3.Phylum.Farmland.csv"), 
                     header = TRUE, sep = ",", stringsAsFactors = FALSE)
Class <- read.table(file.path(MLpath, "res.unoise3.Class.Farmland.csv"), 
                    header = TRUE, sep = ",", stringsAsFactors = FALSE)
Order <- read.table(file.path(MLpath, "res.unoise3.Order.Farmland.csv"), 
                    header = TRUE, sep = ",", stringsAsFactors = FALSE)
Family <- read.table(file.path(MLpath, "res.unoise3.Family.Farmland.csv"), 
                     header = TRUE, sep = ",", stringsAsFactors = FALSE)
Genus <- read.table(file.path(MLpath, "res.unoise3.Genus.Farmland.csv"), 
                    header = TRUE, sep = ",", stringsAsFactors = FALSE)
Species <- read.table(file.path(MLpath, "res.unoise3.Species.Farmland.csv"), 
                      header = TRUE, sep = ",", stringsAsFactors = FALSE)
Accuracy.all1 <- data.frame(method  = Kingdom[, 1],
                            Kingdom = Kingdom[, 2],
                            Phylum = Phylum[, 2],
                            Class = Class[, 2],
                            Order = Order[, 2],
                            Family = Family[, 2],
                            Genus = Genus[, 2],
                            Species = Species[, 2])
# 将数据转换为长格式
Accuracy.all2 <- data.frame(
  #method = c("RandomForest", "XGBoost", "Generalized Linear Model", "Support Vector Machine", "Deep Learning"),
  method = c("RandomForest",  "Support Vector Machine", "Deep Learning"),
  Kingdom = Accuracy.all1$Kingdom,
  Phylum = Accuracy.all1$Phylum,
  Class = Accuracy.all1$Class,
  Order = Accuracy.all1$Order,
  Family = Accuracy.all1$Family,
  Genus = Accuracy.all1$Genus,
  Species = Accuracy.all1$Species
)
#Accuracy.all2[, -1] <- round(Accuracy.all2[, -1], 3)

library(reshape2)
#将数据转换为长格式
Accuracy.long <- melt(Accuracy.all2, id.vars = "method", 
                      variable.name = "TaxonomicLevel", value.name = "Accuracy")
#四舍五入
#Accuracy.long$Accuracy <- round(Accuracy.long$Accuracy, 2)
# 计算每种方法的平均 Accuracy
mean_accuracy <- Accuracy.long %>%
  group_by(method) %>%
  summarise(mean_accuracy = mean(Accuracy, na.rm = TRUE)) %>%
  arrange(desc(mean_accuracy))
# 将方法按照平均 Accuracy 排序
Accuracy.long$method <- factor(Accuracy.long$method, levels = mean_accuracy$method)
# 绘图
p.Acc <- ggplot(Accuracy.long, aes(x = TaxonomicLevel, y = Accuracy, color = method, group = method)) +
  geom_line(size=1.5) +
  geom_point(size = 3) +
  labs(
    x = "Taxonomic Level",
    y = "Accuracy") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),  # 去掉主要网格线
        panel.grid.minor = element_blank(),  # 去掉次要网格线
        axis.line.x = element_line(color = "black",size = 1),  # 保留x轴线
        axis.line.y = element_line(color = "black", size = 1),  # 保留y轴线
        axis.ticks.x = element_line(color = "black",size=1),  # 添加横坐标刻度
        axis.ticks.y = element_line(color = "black",size=1),#添加纵坐标刻度
        axis.text.x = element_text(color = "black", size = 20,face = "bold"),  # x轴刻度标签的颜色和大小),
        axis.text.y = element_text(color = "black", size = 20,face = "bold"),  # y轴刻度标签的颜色和大小  
        axis.title.x = element_text(color = "black", size = 20,face = "bold"),  # x轴标题的颜色和大小  
        axis.title.y = element_text(color = "black", size = 20,face = "bold"),  # y轴标题的颜色和大小  
        plot.title = element_text(hjust = 0.5),
        legend.title = element_blank(),# 去掉图例标题
        #legend.position = c(0.9,0.8),
        legend.text = element_text(color = "black",size = 20,face = "bold"),
        legend.position = c(0.55, 0.25))  
p.Acc



#1.随机森林#------
map = as.data.frame(phyloseq::sample_data(ps.cs))
otutab = as.data.frame(t(ggClusterNet::vegan_otu(ps.cs)))
colnames(otutab) <- gsub("-","_",colnames(otutab)) 
#sum.row <- rowSums(otutab)
#otutab1 <- otutab[which(rowSums(otutab) >= mean(sum.row)), ]
#test = as.data.frame(t(otutab1))
test = as.data.frame(t(otutab))
test$group = factor(map$Group)
test <- test[, colnames(test) != "Unassigned"]
#colnames(test) = paste("OTU",colnames(test),sep = "")

colnames(test) <- gsub("-","_",colnames(test))
colnames(test) <- gsub("[/]","_",colnames(test))
colnames(test) <- gsub("[(]","_",colnames(test))
colnames(test) <- gsub("[)]","_",colnames(test))
colnames(test) <- gsub("[:]","_",colnames(test))
colnames(test) <- gsub("[[]","",colnames(test))
colnames(test) <- gsub("[]]","_",colnames(test))
colnames(test) <- gsub("[#]","_",colnames(test))
colnames(test) <- gsub("[+]","_",colnames(test))
colnames(test) <- gsub(" ","_",colnames(test))

test = dplyr::select(test,group,everything())
train = test

#set.seed(123)
#select_train <- sample(4575, 4575*0.9)
#otu_train <- train[select_train, ]
#otu_test <- train[-select_train, ]
#otu_train.forest <- randomForest(OTUgroup~., data = otu_train, importance = TRUE)
#otu_train.forest
#train_predict <- predict(otu_train.forest, otu_train)
#compare_train <- table(train_predict, otu_train$OTUgroup)
#compare_train
#sum(diag(compare_train)/sum(compare_train))

#test_predict <- predict(otu_train.forest, otu_test)
#compare_test <- table(otu_test$OTUgroup, test_predict, dnn = c('Actual', 'Predicted'))
#compare_test


set.seed(123)
folds <- createFolds(y=test[,1],k=10)
index.train <- sample(length(test[,1]),length(test[,1])*0.9)
fold_train<-train[index.train,]
fold_test<-train[-index.train,]

#plant_predict <- predict(model, fold_train)

set.seed(123)
otu_train.cv1 <- replicate(10, rfcv(fold_train[-1], fold_train$group, cv.fold = 10,step = 1.5), simplify = FALSE)
otu_train.cv1

otu_train.cv <- data.frame(sapply(otu_train.cv1, '[[', 'error.cv'))
otu_train.cv$otus <- rownames(otu_train.cv)
otu_train.cv <- reshape2::melt(otu_train.cv, id = 'otus')
otu_train.cv$otus <- as.numeric(as.character(otu_train.cv$otus))

library(ggplot2)
library(splines)

p.cv <- ggplot(otu_train.cv, aes(otus, value)) +
  geom_smooth(se = FALSE,  method = 'glm', formula = y ~ ns(x, 6)) +
  theme(panel.grid = element_blank(), 
        panel.background = element_rect(fill = 'transparent'),  # 去掉背景色
        panel.border = element_blank(),  # 去掉所有边框
        axis.line.x = element_line(color = 'black',size=1),  # 仅保留x轴线
        axis.line.y = element_line(color = 'black',size=1),
        axis.ticks.x = element_line(color = "black",size=1),  # 添加横坐标刻度
        axis.ticks.y = element_line(color = "black",size=1),#添加纵坐标刻度
        axis.text.x = element_text(color = "black", size = 14,face = "bold"),  # x轴刻度标签的颜色和大小),
        axis.text.y = element_text(color = "black", size = 14,face = "bold"),  # y轴刻度标签的颜色和大小  
        axis.title.x = element_text(color = "black", size = 14,face = "bold"),  # x轴标题的颜色和大小  
        axis.title.y = element_text(color = "black", size = 14,face = "bold"),  # y轴标题的颜色和大小  
        ) +  # 仅保留y轴线
  labs(title = '', x = 'Number of Genus-level OTUs', y = 'Cross-validation error')
p.cv
optimal.value <- 50
p.cv + geom_vline(xintercept = optimal.value,linetype = "dashed",color = "red",size=1)+
            annotate("text", x = optimal.value, y = max(otu_train.cv$value), 
           label = paste0("optimal value = ",optimal.value), color = "red",  hjust = -0.1,fontface = "bold")

#normal CV Error plot
#error.cv= sapply(otu_train.cv1, "[[", "error.cv")
#matplot(otu_train.cv1[[1]]$n.var, cbind(rowMeans(error.cv), error.cv), type="l",
#        lwd=c(2, rep(1, ncol(error.cv))), col=1, lty=1, log="x",
#        xlab="Number of variables", ylab="CV Error")
set.seed(123)
model<-randomForest(group~.,data=fold_train, 
                    importance=TRUE, proximity=TRUE)
df<-data.frame(importance(model), check.names = F)
importance_otu <-df[order(df$MeanDecreaseAccuracy,decreasing = T),]
importance_otu <- importance_otu[1:optimal.value,]
head(importance_otu)
OTU = as.data.frame(t(test[-1]))
OTU_top <- OTU[match(rownames(importance_otu), rownames(OTU)), ]
data <- cbind(t(OTU_top),test$group)
pp<-aggregate(data[,1:optimal.value],by=list(data[,ncol(data)]),FUN=mean)
io=melt(pp,id.vars = c("Group.1"),value.name ="Value",variable.name = "OTU")
io$Group.1 <- ifelse(io$Group.1 == 1, "Biochar", "Control")
# 将 Group.1 转换为因子类型
io$Group.1 <- as.factor(io$Group.1)
# 检查结果
head(io)

#气泡图
p1 = ggplot(io, aes(x=Group.1,y=reorder(OTU, Value))) +
  geom_point(aes(size = abs(Value),colour=Group.1))+
  scale_colour_manual(values=c("#0eb0c8","#f2ccac","#a1d5b9","#e1abbc"))+
  theme_bw(base_size = 12)+
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        axis.title.x = element_blank()) +# 去除 X 轴标题
  labs(y = "OTU",size = "Relative Abundance(%)")+
  scale_size(range = c(0, 14),breaks=c(0,5,10,20), limits=c(0,400))+ 
  guides(colour = guide_legend(override.aes = list(size=5))) +
  theme(axis.text=element_text(colour='black',size=9))
p1

p1 <- p1 + 
  guides(colour = guide_none())  # 去掉颜色相关的图例

# 打印图形
print(p1)

#基于MeanDecreaseAccuracy的翻转条形图
dataframe <- cbind(importance_otu, rownames(importance_otu))
p.m = ggplot(dataframe, aes(x = reorder(rownames(dataframe), -dataframe$MeanDecreaseAccuracy), y = -MeanDecreaseAccuracy, fill = rownames(dataframe))) +   
  geom_bar(stat = "identity", width = 0.9,alpha=0.6, colour="black") +   
  labs(x="", y="MeanDecreaseAccuracy") +  
  theme_bw() +  
  theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank(),
        panel.border = element_blank(),  # 去掉所有边框,
        axis.line.y = element_line(color = "black",size=1),
        axis.ticks.x = element_line(color = "black",size=1),  # 添加横坐标刻度
        axis.ticks.y = element_line(color = "black",size=1),#添加纵坐标刻度
        axis.text.y = element_text(color = "black",size=14,face = "bold"),  # y轴刻度标签的颜色和大小  
        axis.title.y = element_text(color = "black", size = 14,face = "bold"),  # y轴标题的颜色和大小  
        
        plot.margin = unit(c(5.5, 5.5, -10, 10), "pt"))+  
  # 如果X轴的标签太长，可以考虑旋转它们  
  theme(axis.text.x = element_text(angle = 45, hjust = 1,color = "black",size=9,face = "bold")) +  
  theme(legend.position = "none") +  # 如果没有图例，则设置为"none"
  scale_y_continuous(labels = abs,expand = c(0, 0.5),breaks = scales::pretty_breaks(n = 5)) +# 将纵坐标的标签改为正值显示
  scale_fill_manual(values = rainbow(nrow(dataframe)))  # 使用不同的颜色

# 显示图形  
print(p.m)

# 添加网格线和去除标签连接
#p.m1 <- p.m + 
#  theme(panel.grid.major = element_line(color = "grey90", size = 0.5),
#        axis.line.y = element_blank())+
#  theme(axis.ticks.y = element_blank(),
#        axis.line.y = element_blank(),
#        axis.text.y = element_blank()) # 主要网格线
#p.m1

#气泡图+翻转条形图
#library(patchwork)
#p=p1+p.m+plot_layout(nrow = 1, widths = c(2, 4),
#                    guides = "collect")
#p
#ggsave( 'RF_OTU.png', width = 7, height = 5)



ggplot(io, aes(x = OTU, y = Value, fill = Group.1)) +
  geom_bar(stat = "identity") +  # 默认情况下为堆叠
  labs(x = "OTU", y = "Relative Abundance", title = "Relative Abundance of Different OTUs by Group") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),  # X 轴标签旋转
        legend.title = element_blank()) +  # 去掉图例标题
  scale_fill_manual(values = c("Biochar" = "#0eb0c8", "Control" = "#f2ccac"))  # 设置颜色

data2 <- data
test1 <- test
data2 <- as.data.frame(data2)
test1 <- as.data.frame(test1)
data2[, ncol(data2)] <- test$group
colnames(data2)[ncol(data2)] <- "Condition"
# 转换数据为长格式
data_long <- data2 %>%
  pivot_longer(cols = -Condition, names_to = "OTU", values_to = "Abundance")

# 计算每个 OTU 的 P 值,
#t.test方法
#p_values <- data_long %>%
#  group_by(OTU) %>%
#  reframe(p_value = t.test(Abundance ~ Condition)$p.value) %>%
#  mutate(p_adjust = p.adjust(p_value, method = "BH"))



library(dplyr)
#Kruskal-Wallis方法
p_values <- data_long %>%
  group_by(OTU) %>%
  reframe(p_value = kruskal.test(Abundance ~ Condition)$p.value) %>%
  mutate(p_adjust = p.adjust(p_value, method = "BH"))


# 添加显著性标记
#data_long <- data_long %>%
#  left_join(p_values, by = "OTU") %>%
#  mutate(Significance = ifelse(p_adjust < 0.05, "*", ""))
data_long <- data_long %>%
  left_join(p_values, by = "OTU") %>%
  mutate(Significance = ifelse(p_adjust < 0.05, "*", ""))


# 创建堆叠条形图
#io$OTU <- gsub("^OTU", "", io$OTU)
ggplot(io, aes(x = OTU, y = Value, fill = Group.1)) +
  geom_bar(stat = "identity") +  # 默认情况下为堆叠
  labs(x = "OTU", y = "Relative Abundance", title = "Relative Abundance of Different OTUs by Group") +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),  # X 轴标签旋转
        legend.title = element_blank()) +  # 去掉图例标题
  scale_fill_manual(values = c("Biochar" = "#0eb0c8", "Control" = "#f2ccac"))  # 设置颜色


io_with_p <- io %>%  
  left_join(p_values, by = "OTU")  
# 设置显著性阈值  
significance_threshold <- 0.05  
# 创建一个新的列，用于在显著OTU上添加“*”  
io_with_p$significant <- ""
# 获取所有唯一的 OTU
unique_otus <- unique(io_with_p$OTU)
# 循环遍历每个 OTU
for (otu in unique_otus) {
  # 筛选出相同 OTU 的行且 p 值小于显著性阈值
  subset_otu <- io_with_p[io_with_p$OTU == otu & io_with_p$p_adjust < significance_threshold, ]
  # 如果有行符合条件
  if (nrow(subset_otu) > 0) {
    # 找到 p 值较大的行
    max_Value_row <- which.max(subset_otu$Value)
    # 在较大 p 值的行中标记 "*"
    io_with_p$significant[io_with_p$OTU == otu & io_with_p$p_value < significance_threshold][max_Value_row] <- "*"
  }
}
# 计算每个 OTU 组堆叠条形的顶部位置
io_with_p <- io_with_p %>%  
  group_by(OTU) %>%  
  mutate(OTU_Value_Sum = sum(Value, na.rm = TRUE)) %>%  
  ungroup() 
# 查看更新后的 io_with_p
io_with_p

max_otu <- io %>%
  dplyr::arrange(desc(Value)) %>%
  dplyr::slice(1) %>%
  dplyr::pull(OTU)
# 计算这个OTU在Biochar和Control组中的Value值之和  
otu_sum <- io %>%  
  filter(OTU == max_otu) %>%  
  group_by(OTU) %>%  
  summarise(total_value = sum(Value, na.rm = TRUE), .groups = 'drop')  
y.lim <- otu_sum$total_value

ggplot(io, aes(x = OTU, y = Value, fill = Group.1)) +
  geom_bar(stat = "identity") +  # 默认情况下为堆叠
  labs(x = "",y = "Relative Abundance") +
  theme_bw() +
  theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank(),
        axis.text.x = element_blank(),  # 去掉X轴标签
        axis.ticks.x = element_blank(),  # 去掉X轴刻度
        legend.title = element_blank(),  # 去掉图例标题
        panel.border = element_blank(),  # 去掉所有边框
        axis.line.y = element_line(color = "black",size=1),
        axis.line.x = element_line(color = "black",size=1),
        
        axis.ticks.y = element_line(color = "black",size=1),#添加纵坐标刻度
        
        axis.text.y = element_text(color = "black", size = 14,face = "bold"),  # y轴刻度标签的颜色和大小  
        
        axis.title.y = element_text(color = "black", size = 14,face = "bold"),  # y轴标题的颜色和大小  
        plot.margin = unit(c(5.5, 5.5, -10, 10), "pt"),
        legend.position = c(0.9,0.8),
        legend.text = element_text(color = "black",, size = 14,face = "bold")) +  # 设置图例字体大小) +  
  scale_fill_manual(values = c("Biochar" = "#0eb0c8", "Control" = "#f2ccac"),name = "Group")+  # 设置颜色
  geom_text(data = io_with_p[io_with_p$significant == "*", ], 
            aes( y = OTU_Value_Sum,label = significant,colour = Group.1),
          vjust = 0, size = 6) +  # 调整标记的垂直位置和大小
  
  scale_color_manual(values = c("Biochar" = "#0eb0c8", "Control" = "#f2ccac"),name = "Group")+
  #scale_x_discrete(expand = c(0, 0)) #+  # X轴从原点开始
  scale_y_continuous(expand = c(0, 0),limits = c(0,y.lim+0.5 ),breaks = seq(0, y.lim+0.5, by = 2))  # Y轴从原点开始，刻度为整数



# 使用 pivot_wider 将数据框转换为宽格式
new_df <- io_with_p %>%
  select(Group.1, OTU, Value, p_value,p_adjust) %>%
  pivot_wider(names_from = Group.1, values_from = Value) %>%
  rename(Genus = OTU, RA_Biochar = Biochar, RA_Control = Control)
new_df <- as.data.frame(new_df)
# 查看新的数据框
print(new_df)
importance_df <- data.frame(
  Genus = new_df$Genus,
  MeanDecreaseAccuracy = importance_otu$MeanDecreaseAccuracy,
  RA_Biochar = new_df$RA_Biochar,
  RA_Control = new_df$RA_Control,
  p_value = new_df$p_value,
  p_adjust = new_df$p_adjust
)
# 添加新列，判断 p_value 是否小于 0.05
importance_df <- importance_df %>%
  mutate(Significant = ifelse(p_adjust < 0.05, "*", "ns"))
head(importance_df)
FileName <- paste(MLpath,"/Biomarker.Genus.Farmland.k.csv", sep = "")
write.csv(importance_df,FileName,row.names = FALSE, col.names = T)


#重新加载 dplyr 包
library(dplyr)
# 使用 dplyr 包的 select 函数
significant_otus <- io_with_p %>%
  filter(significant == "*") %>%
  dplyr::select(Group.1, OTU,Value,p_value,p_adjust,significant )
# 查看结果
print(significant_otus)
FileName <- paste(MLpath,"/significant_otus.Genus.Farmland.k.csv", sep = "")
write.csv(significant_otus,FileName,row.names = FALSE, col.names = FALSE)


